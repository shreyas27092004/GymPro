package com.gympro.booking;

import com.gympro.booking.dto.BookingRequest;
import com.gympro.booking.entity.Booking;
import com.gympro.booking.exception.BookingNotFoundException;
import com.gympro.booking.feign.NotificationClient;
import com.gympro.booking.repository.BookingRepository;
import com.gympro.booking.service.BookingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BookingServiceTest {

    @Mock private BookingRepository repo;
    @Mock private NotificationClient notificationClient;
    @InjectMocks private BookingService bookingService;

    private BookingRequest validRequest;

    @BeforeEach
    void setUp() {
        validRequest = new BookingRequest();
        validRequest.setMemberId(1L);
        validRequest.setMemberEmail("shreyas@gmail.com");
        validRequest.setTrainerId(1L);
        validRequest.setTrainerEmail("ravi@gmail.com");
        validRequest.setSessionDay("MON");
        validRequest.setSessionTime("09:00 - 11:00");
        validRequest.setScheduleId(1L);
    }

    @Test
    void testCreateBooking_Success() {
        when(repo.save(any(Booking.class))).thenAnswer(inv -> {
            Booking b = inv.getArgument(0);
            b.setId(1L);
            return b;
        });

        Booking result = bookingService.createBooking(validRequest);

        assertNotNull(result);
        assertEquals("CONFIRMED", result.getStatus());
        assertEquals(1L, result.getMemberId());
        verify(repo, times(1)).save(any(Booking.class));
    }

    @Test
    void testCreateBooking_NullMemberId_ThrowsException() {
        validRequest.setMemberId(null);

        assertThrows(IllegalArgumentException.class, () ->
            bookingService.createBooking(validRequest)
        );
        verify(repo, never()).save(any());
    }

    @Test
    void testGetBookingById_NotFound_ThrowsException() {
        when(repo.findById(anyLong())).thenReturn(Optional.empty());

        BookingNotFoundException ex = assertThrows(BookingNotFoundException.class, () ->
            bookingService.getBookingById(999L)
        );

        assertTrue(ex.getMessage().contains("Booking not found with id: 999"));
    }

    @Test
    void testCancelBooking_Success() {
        Booking confirmedBooking = new Booking();
        confirmedBooking.setId(1L);
        confirmedBooking.setStatus("CONFIRMED");
        confirmedBooking.setMemberEmail("shreyas@gmail.com");

        when(repo.findById(1L)).thenReturn(Optional.of(confirmedBooking));
        when(repo.save(any(Booking.class))).thenReturn(confirmedBooking);

        String result = bookingService.cancelBooking(1L);

        assertTrue(result.contains("cancelled"));
        assertEquals("CANCELLED", confirmedBooking.getStatus());
    }

    @Test
    void testCancelBooking_AlreadyCompleted_ThrowsException() {
        Booking completedBooking = new Booking();
        completedBooking.setId(1L);
        completedBooking.setStatus("COMPLETED");

        when(repo.findById(1L)).thenReturn(Optional.of(completedBooking));

        assertThrows(IllegalArgumentException.class, () ->
            bookingService.cancelBooking(1L)
        );
    }

    @Test
    void testCompleteBooking_Success() {
        Booking confirmedBooking = new Booking();
        confirmedBooking.setId(1L);
        confirmedBooking.setStatus("CONFIRMED");

        when(repo.findById(1L)).thenReturn(Optional.of(confirmedBooking));
        when(repo.save(any(Booking.class))).thenReturn(confirmedBooking);

        Booking result = bookingService.completeBooking(1L);
        assertEquals("COMPLETED", result.getStatus());
    }
}
