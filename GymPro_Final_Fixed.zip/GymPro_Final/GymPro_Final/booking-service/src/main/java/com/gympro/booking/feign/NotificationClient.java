package com.gympro.booking.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

// ✅ Feign Client – automatically calls notification-service
// Spring Cloud creates the HTTP implementation – no manual code needed
@FeignClient(name = "notification-service")
public interface NotificationClient {

    // Generic send (used as fallback)
    @PostMapping("/notify/send")
    String sendNotification(@RequestParam("email")   String email,
                            @RequestParam("subject") String subject,
                            @RequestParam("message") String message);

    // Specific booking confirmation for member
    @PostMapping("/notify/booking/member")
    String sendBookingToMember(@RequestParam("to")          String to,
                               @RequestParam("bookingId")   Long bookingId,
                               @RequestParam("trainerName") String trainerName,
                               @RequestParam("day")         String day,
                               @RequestParam("time")        String time);

    // Specific booking notification for trainer
    @PostMapping("/notify/booking/trainer")
    String sendBookingToTrainer(@RequestParam("to")         String to,
                                @RequestParam("bookingId")  Long bookingId,
                                @RequestParam("memberName") String memberName,
                                @RequestParam("day")        String day,
                                @RequestParam("time")       String time);

    // Cancellation email
    @PostMapping("/notify/booking/cancel")
    String sendCancellation(@RequestParam("to")        String to,
                            @RequestParam("bookingId") Long bookingId);
}
