package com.gympro.booking.controller;

import com.gympro.booking.dto.BookingRequest;
import com.gympro.booking.entity.Booking;
import com.gympro.booking.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

// ✅ Role access:
//   POST /bookings/create → MEMBER
//   GET  /bookings/member/{id} → MEMBER (own), ADMIN
//   GET  /bookings/trainer/{id} → TRAINER (own), ADMIN
//   POST /bookings/cancel/{id} → MEMBER, ADMIN
@RestController
@RequestMapping("/bookings")
public class BookingController {

    @Autowired
    private BookingService service;

    // Book a session
    @PostMapping("/create")
    public Booking create(@RequestBody BookingRequest req) {
        return service.createBooking(req);
    }

    // Get one booking
    @GetMapping("/{id}")
    public Booking getById(@PathVariable Long id) {
        return service.getBookingById(id);
    }

    // All bookings for a member
    @GetMapping("/member/{memberId}")
    public List<Booking> byMember(@PathVariable Long memberId) {
        return service.getBookingsByMember(memberId);
    }

    // All bookings for a trainer
    @GetMapping("/trainer/{trainerId}")
    public List<Booking> byTrainer(@PathVariable Long trainerId) {
        return service.getBookingsByTrainer(trainerId);
    }

    // Cancel booking
    @PostMapping("/cancel/{id}")
    public String cancel(@PathVariable Long id) {
        return service.cancelBooking(id);
    }

    // Mark booking as completed
    @PostMapping("/complete/{id}")
    public Booking complete(@PathVariable Long id,
                            @RequestHeader("X-User-Role") String role) {
        if (!"TRAINER".equals(role) && !"ADMIN".equals(role))
            throw new RuntimeException("Access denied ❌");
        return service.completeBooking(id);
    }

    @GetMapping("/test")
    public String test() { return "Booking Service Working ✅"; }
}
