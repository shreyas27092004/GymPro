package com.gympro.booking.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

// ✅ A booking = a MEMBER booked a TRAINER for a session
@Entity
@Table(name = "bookings")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long memberId;
    private String memberEmail;

    private Long trainerId;
    private String trainerEmail;

    private Long scheduleId;         // which time slot was booked
    private String sessionDay;       // e.g. "MON"
    private String sessionTime;      // e.g. "09:00 - 11:00"

    private LocalDate bookingDate;

    private String status;           // CONFIRMED | CANCELLED | COMPLETED
    private String notes;
}
