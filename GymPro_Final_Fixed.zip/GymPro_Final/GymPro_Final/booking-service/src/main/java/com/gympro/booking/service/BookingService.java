package com.gympro.booking.service;

import com.gympro.booking.dto.BookingRequest;
import com.gympro.booking.entity.Booking;
import com.gympro.booking.exception.BookingNotFoundException;
import com.gympro.booking.feign.NotificationClient;
import com.gympro.booking.repository.BookingRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Slf4j
@Service
public class BookingService {

    @Autowired private BookingRepository repo;
    @Autowired private NotificationClient notificationClient;

    @Transactional
    public Booking createBooking(BookingRequest req) {
        if (req.getMemberId() == null || req.getTrainerId() == null)
            throw new IllegalArgumentException("memberId and trainerId are required");
        if (req.getMemberEmail() == null || req.getMemberEmail().isBlank())
            throw new IllegalArgumentException("memberEmail is required");

        Booking booking = new Booking();
        booking.setMemberId(req.getMemberId());
        booking.setMemberEmail(req.getMemberEmail());
        booking.setTrainerId(req.getTrainerId());
        booking.setTrainerEmail(req.getTrainerEmail());
        booking.setScheduleId(req.getScheduleId());
        booking.setSessionDay(req.getSessionDay());
        booking.setSessionTime(req.getSessionTime());
        booking.setBookingDate(LocalDate.now());
        booking.setStatus("CONFIRMED");
        booking.setNotes(req.getNotes());

        Booking saved = repo.save(booking);
        log.info("Booking created: id={} for member={}", saved.getId(), saved.getMemberId());

        try {
            notificationClient.sendBookingToMember(
                req.getMemberEmail(), saved.getId(),
                "Trainer #" + req.getTrainerId(), req.getSessionDay(), req.getSessionTime());
            notificationClient.sendBookingToTrainer(
                req.getTrainerEmail(), saved.getId(),
                "Member #" + req.getMemberId(), req.getSessionDay(), req.getSessionTime());
        } catch (Exception e) {
            log.warn("Notification failed (booking still created): {}", e.getMessage());
        }

        return saved;
    }

    @Transactional(readOnly = true)
    public Booking getBookingById(Long id) {
        return repo.findById(id)
            .orElseThrow(() -> new BookingNotFoundException("Booking not found with id: " + id));
    }

    @Transactional(readOnly = true)
    public List<Booking> getBookingsByMember(Long memberId) {
        return repo.findByMemberId(memberId);
    }

    @Transactional(readOnly = true)
    public List<Booking> getBookingsByTrainer(Long trainerId) {
        return repo.findByTrainerId(trainerId);
    }

    @Transactional
    public String cancelBooking(Long id) {
        Booking booking = getBookingById(id);

        if ("COMPLETED".equals(booking.getStatus()))
            throw new IllegalArgumentException("Cannot cancel a COMPLETED booking");

        booking.setStatus("CANCELLED");
        repo.save(booking);
        log.info("Booking cancelled: id={}", id);

        try {
            notificationClient.sendCancellation(booking.getMemberEmail(), id);
        } catch (Exception e) {
            log.warn("Cancellation email failed: {}", e.getMessage());
        }

        return "Booking #" + id + " cancelled successfully";
    }

    @Transactional
    public Booking completeBooking(Long id) {
        Booking booking = getBookingById(id);

        if ("CANCELLED".equals(booking.getStatus()))
            throw new IllegalArgumentException("Cannot complete a CANCELLED booking");

        booking.setStatus("COMPLETED");
        return repo.save(booking);
    }
}
