package com.gympro.payment.controller;

import com.gympro.payment.dto.PaymentRequest;
import com.gympro.payment.dto.RazorpayOrderResponse;
import com.gympro.payment.entity.Payment;
import com.gympro.payment.service.PaymentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/payments")
public class PaymentController {

    @Autowired
    private PaymentService service;

    // ─── RAZORPAY ORDER (call before showing payment UI) ──────────────────
    // POST /payments/create-order?amount=999&description=Booking%20#5
    @PostMapping("/create-order")
    public ResponseEntity<RazorpayOrderResponse> createOrder(
            @RequestParam Double amount,
            @RequestParam(defaultValue = "GymPro Payment") String description) {

        log.info("Creating Razorpay order: amount=₹{}", amount);
        return ResponseEntity.ok(service.createRazorpayOrder(amount, description));
    }

    // ─── PROCESS PAYMENT ──────────────────────────────────────────────────
    // For dummy (UPI/CASH/QR): Body without razorpay fields
    // For Razorpay: Body with razorpayOrderId + razorpayPaymentId + razorpaySignature
    @PostMapping("/pay")
    public ResponseEntity<Payment> pay(@RequestBody PaymentRequest req) {
        log.info("Payment request: member={}, amount=₹{}, method={}",
            req.getMemberEmail(), req.getAmount(), req.getPaymentMethod());
        return ResponseEntity.ok(service.processPayment(req));
    }

    // ─── GET ENDPOINTS ────────────────────────────────────────────────────

    @GetMapping("/my/{memberId}")
    public ResponseEntity<List<Payment>> getMyPayments(@PathVariable Long memberId) {
        return ResponseEntity.ok(service.getByMember(memberId));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Payment> getById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getById(id));
    }

    @GetMapping("/txn/{txnId}")
    public ResponseEntity<Payment> getByTxn(@PathVariable String txnId) {
        return ResponseEntity.ok(service.getByTransactionId(txnId));
    }

    @GetMapping("/booking/{bookingId}")
    public ResponseEntity<Payment> getByBooking(@PathVariable Long bookingId) {
        return ResponseEntity.ok(service.getByBookingId(bookingId));
    }

    @GetMapping("/all")
    public ResponseEntity<List<Payment>> getAll(
            @RequestHeader("X-User-Role") String role) {
        if (!"ADMIN".equals(role)) throw new SecurityException("ADMIN only");
        return ResponseEntity.ok(service.getAll());
    }

    // ─── REFUND ───────────────────────────────────────────────────────────
    @PostMapping("/refund/{id}")
    public ResponseEntity<Payment> refund(
            @PathVariable Long id,
            @RequestHeader("X-User-Role") String role) {
        return ResponseEntity.ok(service.refund(id, role));
    }

    @GetMapping("/test")
    public String test() { return "Payment Service Working ✅ — Razorpay integrated"; }
}
