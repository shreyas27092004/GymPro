package com.gympro.payment.service;

import com.gympro.payment.dto.PaymentRequest;
import com.gympro.payment.dto.RazorpayOrderResponse;
import com.gympro.payment.entity.Payment;
import com.gympro.payment.exception.PaymentException;
import com.gympro.payment.exception.PaymentNotFoundException;
import com.gympro.payment.feign.NotificationClient;
import com.gympro.payment.repository.PaymentRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

// ✅ PaymentService – handles all payment business logic
//
// TWO payment modes:
// 1. RAZORPAY  → Real payment via Razorpay (use for CREDIT_CARD, DEBIT_CARD, UPI via Razorpay)
// 2. DUMMY     → Simulated payment (use for testing: UPI, QR_CODE, CASH)
@Slf4j
@Service
@Transactional
public class PaymentService {

    @Autowired private PaymentRepository repo;
    @Autowired private NotificationClient notificationClient;
    @Autowired private RazorpayService razorpayService;

    // List of payment methods we accept
    private static final List<String> VALID_METHODS =
        List.of("CREDIT_CARD", "DEBIT_CARD", "UPI", "QR_CODE", "CASH", "RAZORPAY");

    // ─── STEP 1: Create Razorpay Order (call this before showing payment UI) ──
    public RazorpayOrderResponse createRazorpayOrder(Double amount, String description) {
        if (amount == null || amount <= 0) {
            throw new PaymentException("Amount must be greater than 0");
        }
        return razorpayService.createOrder(amount, description);
    }

    // ─── STEP 2: Process Payment ──────────────────────────────────────────────
    // For Razorpay: verifies signature then records payment
    // For others (UPI/QR/CASH): directly records as SUCCESS (dummy)
    public Payment processPayment(PaymentRequest req) {

        // Validate all inputs first
        validatePaymentRequest(req);

        Payment payment = buildPayment(req);

        // Decide which payment mode to use
        if ("RAZORPAY".equalsIgnoreCase(req.getPaymentMethod())) {
            payment = processRazorpayPayment(payment, req);
        } else {
            payment = processDummyPayment(payment, req);
        }

        Payment saved = repo.save(payment);
        log.info("✅ Payment saved: id={}, txn={}, status={}", saved.getId(), saved.getTransactionId(), saved.getStatus());

        // Send email receipt to member
        sendPaymentReceiptEmail(saved);

        return saved;
    }

    // Process real Razorpay payment (verifies signature)
    private Payment processRazorpayPayment(Payment payment, PaymentRequest req) {
        if (req.getRazorpayOrderId() == null || req.getRazorpayPaymentId() == null || req.getRazorpaySignature() == null) {
            throw new PaymentException(
                "For RAZORPAY method, provide: razorpayOrderId, razorpayPaymentId, razorpaySignature"
            );
        }

        // Verify the payment is genuine
        boolean isValid = razorpayService.verifyPayment(
            req.getRazorpayOrderId(),
            req.getRazorpayPaymentId(),
            req.getRazorpaySignature()
        );

        if (!isValid) {
            payment.setStatus("FAILED");
            payment.setTransactionId("FAILED-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
            repo.save(payment);
            throw new PaymentException("Payment verification failed! Invalid signature.");
        }

        payment.setTransactionId(req.getRazorpayPaymentId());  // Use Razorpay payment ID as TXN
        payment.setStatus("SUCCESS");
        payment.setPaidAt(LocalDateTime.now());
        log.info("✅ Razorpay payment verified: {}", req.getRazorpayPaymentId());
        return payment;
    }

    // Process dummy payment (always succeeds – for testing)
    private Payment processDummyPayment(Payment payment, PaymentRequest req) {
        // Generate internal transaction ID
        String txnId = "TXN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        payment.setTransactionId(txnId);
        payment.setStatus("SUCCESS");
        payment.setPaidAt(LocalDateTime.now());
        log.info("✅ Dummy payment processed: txn={}", txnId);
        return payment;
    }

    // Build a Payment entity from the request
    private Payment buildPayment(PaymentRequest req) {
        Payment p = new Payment();
        p.setMemberId(req.getMemberId());
        p.setMemberEmail(req.getMemberEmail());
        p.setBookingId(req.getBookingId());
        p.setSubscriptionId(req.getSubscriptionId());
        p.setAmount(req.getAmount());
        p.setPaymentMethod(req.getPaymentMethod().toUpperCase());
        p.setDescription(req.getDescription());
        p.setStatus("PENDING");
        return p;
    }

    // ─── GETTERS ──────────────────────────────────────────────────────────────

    public List<Payment> getByMember(Long memberId) {
        return repo.findByMemberId(memberId);
    }

    public Payment getById(Long id) {
        return repo.findById(id)
            .orElseThrow(() -> new PaymentNotFoundException("Payment not found with id: " + id));
    }

    public Payment getByTransactionId(String txnId) {
        return repo.findByTransactionId(txnId)
            .orElseThrow(() -> new PaymentNotFoundException("Payment not found with txnId: " + txnId));
    }

    public Payment getByBookingId(Long bookingId) {
        return repo.findByBookingId(bookingId)
            .orElseThrow(() -> new PaymentNotFoundException("No payment found for booking: " + bookingId));
    }

    public List<Payment> getAll() {
        return repo.findAll();
    }

    // ─── REFUND ───────────────────────────────────────────────────────────────
    public Payment refund(Long id, String role) {
        if (!"ADMIN".equals(role)) {
            throw new SecurityException("Access denied – only ADMIN can issue refunds");
        }

        Payment payment = getById(id);

        if (!"SUCCESS".equals(payment.getStatus())) {
            throw new PaymentException(
                "Cannot refund payment with status: " + payment.getStatus() +
                ". Only SUCCESS payments can be refunded."
            );
        }

        payment.setStatus("REFUNDED");
        Payment saved = repo.save(payment);
        log.info("✅ Refund processed for payment: {}", id);

        // Send refund email
        try {
            notificationClient.sendRefundEmail(
                payment.getMemberEmail(),
                payment.getAmount(),
                payment.getTransactionId()
            );
        } catch (Exception e) {
            log.warn("⚠️ Refund email failed (payment still refunded): {}", e.getMessage());
        }

        return saved;
    }

    // ─── PRIVATE HELPERS ─────────────────────────────────────────────────────

    private void validatePaymentRequest(PaymentRequest req) {
        if (req.getMemberId() == null) {
            throw new PaymentException("memberId is required");
        }
        if (req.getMemberEmail() == null || req.getMemberEmail().isBlank()) {
            throw new PaymentException("memberEmail is required");
        }
        if (req.getAmount() == null || req.getAmount() <= 0) {
            throw new PaymentException("amount must be greater than 0");
        }
        if (req.getPaymentMethod() == null || req.getPaymentMethod().isBlank()) {
            throw new PaymentException("paymentMethod is required");
        }
        if (!VALID_METHODS.contains(req.getPaymentMethod().toUpperCase())) {
            throw new PaymentException(
                "Invalid paymentMethod: " + req.getPaymentMethod() +
                ". Valid options: " + VALID_METHODS
            );
        }
    }

    private void sendPaymentReceiptEmail(Payment payment) {
        try {
            notificationClient.sendPaymentReceipt(
                payment.getMemberEmail(),
                payment.getAmount(),
                payment.getPaymentMethod(),
                payment.getTransactionId(),
                payment.getDescription() != null ? payment.getDescription() : "GymPro Payment"
            );
        } catch (Exception e) {
            log.warn("⚠️ Payment receipt email failed (payment still recorded): {}", e.getMessage());
        }
    }
}
