package com.gympro.payment.dto;

import lombok.Data;

// DTO = Data Transfer Object
// What the client sends in the request body when making a payment
@Data
public class PaymentRequest {

    // Who is paying
    private Long memberId;
    private String memberEmail;

    // What are they paying for (at least one should be set)
    private Long bookingId;          // For booking a session
    private Long subscriptionId;     // For subscribing to a plan

    // Payment details
    private Double amount;           // Amount in rupees (e.g. 999.0)

    // Payment method:
    // CREDIT_CARD | DEBIT_CARD | UPI | QR_CODE | CASH = dummy (always succeeds)
    // RAZORPAY = real payment (needs razorpay fields below)
    private String paymentMethod;

    private String description;      // Human readable e.g. "Booking #5 - Ravi Trainer"

    // ─── Razorpay fields (only for RAZORPAY method) ────────────────────
    // After frontend completes Razorpay payment, it sends these back
    private String razorpayOrderId;   // e.g. order_ABC123 (from createOrder)
    private String razorpayPaymentId; // e.g. pay_XYZ789 (from Razorpay callback)
    private String razorpaySignature; // HMAC-SHA256 signature for verification
}
