package com.gympro.payment;

import com.gympro.payment.dto.PaymentRequest;
import com.gympro.payment.entity.Payment;
import com.gympro.payment.exception.PaymentException;
import com.gympro.payment.exception.PaymentNotFoundException;
import com.gympro.payment.feign.NotificationClient;
import com.gympro.payment.repository.PaymentRepository;
import com.gympro.payment.service.PaymentService;
import com.gympro.payment.service.RazorpayService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

// ✅ JUnit 5 + Mockito Tests for PaymentService
//
// CONCEPT OF MOCKING:
// We don't want tests to:
//   - Hit the real MySQL database
//   - Call the real Razorpay API
//   - Send real emails
//
// So we MOCK these dependencies:
//   @Mock PaymentRepository  → fake database, returns what we tell it to
//   @Mock NotificationClient → fake email sender, does nothing
//   @Mock RazorpayService    → fake Razorpay, returns what we specify
//
// @InjectMocks PaymentService → REAL service with all @Mock objects injected
@ExtendWith(MockitoExtension.class)
class PaymentServiceTest {

    @Mock
    private PaymentRepository repo;           // Fake database

    @Mock
    private NotificationClient notificationClient;  // Fake email

    @Mock
    private RazorpayService razorpayService;   // Fake Razorpay

    @InjectMocks
    private PaymentService paymentService;     // Real service under test

    private PaymentRequest validRequest;

    // @BeforeEach runs before EVERY test method
    // Sets up common test data
    @BeforeEach
    void setUp() {
        validRequest = new PaymentRequest();
        validRequest.setMemberId(1L);
        validRequest.setMemberEmail("shreyas@gmail.com");
        validRequest.setAmount(999.0);
        validRequest.setPaymentMethod("UPI");
        validRequest.setDescription("Test payment");
        validRequest.setBookingId(1L);
    }

    // ─── TEST 1: Successful UPI payment ──────────────────────────────────
    @Test
    void testProcessPayment_UPI_Success() {
        // ARRANGE: Tell the fake repository to return the payment we give it
        when(repo.save(any(Payment.class))).thenAnswer(invocation -> {
            Payment p = invocation.getArgument(0);
            p.setId(1L);  // Simulate DB assigning an ID
            return p;
        });

        // ACT: Process the payment
        Payment result = paymentService.processPayment(validRequest);

        // ASSERT: Check the result is correct
        assertNotNull(result);
        assertEquals("SUCCESS", result.getStatus());
        assertEquals("UPI", result.getPaymentMethod());
        assertEquals(999.0, result.getAmount());
        assertNotNull(result.getTransactionId());
        assertTrue(result.getTransactionId().startsWith("TXN-"));

        // Verify repo.save() was called exactly once
        verify(repo, times(1)).save(any(Payment.class));
    }

    // ─── TEST 2: Invalid payment method ──────────────────────────────────
    @Test
    void testProcessPayment_InvalidMethod_ThrowsException() {
        validRequest.setPaymentMethod("BITCOIN");  // Not allowed

        // ACT + ASSERT: Should throw PaymentException
        PaymentException ex = assertThrows(PaymentException.class, () ->
            paymentService.processPayment(validRequest)
        );

        assertTrue(ex.getMessage().contains("Invalid paymentMethod"));

        // Verify that the database was NEVER called (validation stopped it)
        verify(repo, never()).save(any(Payment.class));
    }

    // ─── TEST 3: Amount = 0 throws exception ─────────────────────────────
    @Test
    void testProcessPayment_ZeroAmount_ThrowsException() {
        validRequest.setAmount(0.0);

        PaymentException ex = assertThrows(PaymentException.class, () ->
            paymentService.processPayment(validRequest)
        );

        assertTrue(ex.getMessage().contains("amount must be greater than 0"));
    }

    // ─── TEST 4: Null memberId throws exception ───────────────────────────
    @Test
    void testProcessPayment_NullMemberId_ThrowsException() {
        validRequest.setMemberId(null);

        PaymentException ex = assertThrows(PaymentException.class, () ->
            paymentService.processPayment(validRequest)
        );

        assertTrue(ex.getMessage().contains("memberId is required"));
    }

    // ─── TEST 5: Payment not found by ID ─────────────────────────────────
    @Test
    void testGetById_NotFound_ThrowsException() {
        // Tell the fake repo to return empty (payment doesn't exist)
        when(repo.findById(anyLong())).thenReturn(Optional.empty());

        // Should throw PaymentNotFoundException
        PaymentNotFoundException ex = assertThrows(PaymentNotFoundException.class, () ->
            paymentService.getById(999L)
        );

        assertTrue(ex.getMessage().contains("Payment not found with id: 999"));
    }

    // ─── TEST 6: Get payment by ID – success ─────────────────────────────
    @Test
    void testGetById_Success() {
        Payment fakePayment = new Payment();
        fakePayment.setId(1L);
        fakePayment.setStatus("SUCCESS");
        fakePayment.setAmount(999.0);

        // Tell fake repo to return our fakePayment when asked for id=1
        when(repo.findById(1L)).thenReturn(Optional.of(fakePayment));

        Payment result = paymentService.getById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("SUCCESS", result.getStatus());
    }

    // ─── TEST 7: Refund by non-admin throws SecurityException ────────────
    @Test
    void testRefund_NonAdmin_ThrowsSecurityException() {
        SecurityException ex = assertThrows(SecurityException.class, () ->
            paymentService.refund(1L, "MEMBER")  // MEMBER trying to refund
        );

        assertTrue(ex.getMessage().contains("only ADMIN"));
    }

    // ─── TEST 8: Refund of non-SUCCESS payment throws exception ──────────
    @Test
    void testRefund_NonSuccessPayment_ThrowsException() {
        Payment refundedPayment = new Payment();
        refundedPayment.setId(1L);
        refundedPayment.setStatus("REFUNDED");  // Already refunded

        when(repo.findById(1L)).thenReturn(Optional.of(refundedPayment));

        PaymentException ex = assertThrows(PaymentException.class, () ->
            paymentService.refund(1L, "ADMIN")
        );

        assertTrue(ex.getMessage().contains("Cannot refund payment with status: REFUNDED"));
    }

    // ─── TEST 9: Successful refund ────────────────────────────────────────
    @Test
    void testRefund_Admin_Success() {
        Payment successPayment = new Payment();
        successPayment.setId(1L);
        successPayment.setStatus("SUCCESS");
        successPayment.setAmount(999.0);
        successPayment.setMemberEmail("shreyas@gmail.com");
        successPayment.setTransactionId("TXN-ABC123");

        when(repo.findById(1L)).thenReturn(Optional.of(successPayment));
        when(repo.save(any(Payment.class))).thenReturn(successPayment);

        Payment result = paymentService.refund(1L, "ADMIN");

        assertEquals("REFUNDED", result.getStatus());
    }

    // ─── TEST 10: Get all payments ────────────────────────────────────────
    @Test
    void testGetAll_ReturnsAllPayments() {
        Payment p1 = new Payment(); p1.setId(1L);
        Payment p2 = new Payment(); p2.setId(2L);

        when(repo.findAll()).thenReturn(List.of(p1, p2));

        List<Payment> result = paymentService.getAll();

        assertEquals(2, result.size());
        verify(repo, times(1)).findAll();
    }
}
