package com.gympro.plan;

import com.gympro.plan.entity.MembershipPlan;
import com.gympro.plan.entity.MemberSubscription;
import com.gympro.plan.exception.PlanNotFoundException;
import com.gympro.plan.exception.SubscriptionNotFoundException;
import com.gympro.plan.repository.MembershipPlanRepository;
import com.gympro.plan.repository.MemberSubscriptionRepository;
import com.gympro.plan.service.PlanService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PlanServiceTest {

    @Mock private MembershipPlanRepository planRepository;
    @Mock private MemberSubscriptionRepository subRepository;
    @InjectMocks private PlanService planService;

    private MembershipPlan testPlan;

    @BeforeEach
    void setUp() {
        testPlan = new MembershipPlan(1L, "Gold Monthly", "Full gym access", "MONTHLY", 999.0, 30, true);
    }

    @Test
    void createPlan_ShouldSetActiveAndSave() {
        MembershipPlan input = new MembershipPlan(null, "Silver", "Basic", "MONTHLY", 500.0, 0, false);
        when(planRepository.save(any())).thenReturn(testPlan);

        planService.createPlan(input);

        assertTrue(input.isActive());
        assertEquals(30, input.getDurationDays());
        verify(planRepository).save(input);
    }

    @Test
    void createPlan_ShouldThrowIllegalArgument_WhenNameBlank() {
        MembershipPlan input = new MembershipPlan(null, "", "Desc", "MONTHLY", 500.0, 0, false);
        assertThrows(IllegalArgumentException.class, () -> planService.createPlan(input));
        verify(planRepository, never()).save(any());
    }

    @Test
    void createPlan_ShouldSet90Days_ForQuarterly() {
        MembershipPlan input = new MembershipPlan(null, "Q Plan", "Desc", "QUARTERLY", 2000.0, 0, false);
        when(planRepository.save(any())).thenReturn(input);
        planService.createPlan(input);
        assertEquals(90, input.getDurationDays());
    }

    @Test
    void createPlan_ShouldSet365Days_ForYearly() {
        MembershipPlan input = new MembershipPlan(null, "Y Plan", "Desc", "YEARLY", 7000.0, 0, false);
        when(planRepository.save(any())).thenReturn(input);
        planService.createPlan(input);
        assertEquals(365, input.getDurationDays());
    }

    @Test
    void getPlanById_ShouldReturn_WhenFound() {
        when(planRepository.findById(1L)).thenReturn(Optional.of(testPlan));
        MembershipPlan result = planService.getPlanById(1L);
        assertEquals(1L, result.getId());
    }

    @Test
    void getPlanById_ShouldThrowPlanNotFoundException_WhenNotFound() {
        when(planRepository.findById(99L)).thenReturn(Optional.empty());
        assertThrows(PlanNotFoundException.class, () -> planService.getPlanById(99L));
    }

    @Test
    void getActivePlans_ShouldReturnOnlyActive() {
        when(planRepository.findByActive(true)).thenReturn(Arrays.asList(testPlan));
        List<MembershipPlan> result = planService.getActivePlans();
        assertEquals(1, result.size());
        assertTrue(result.get(0).isActive());
    }

    @Test
    void deactivatePlan_ShouldSetActiveFalse() {
        when(planRepository.findById(1L)).thenReturn(Optional.of(testPlan));
        when(planRepository.save(any())).thenReturn(testPlan);

        String result = planService.deactivatePlan(1L);

        assertFalse(testPlan.isActive());
        assertTrue(result.contains("deactivated"));
    }

    @Test
    void subscribe_ShouldCreateActiveSubscription() {
        when(planRepository.findById(1L)).thenReturn(Optional.of(testPlan));
        when(subRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        MemberSubscription result = planService.subscribe(1L, "member@gympro.com", 1L);

        assertNotNull(result);
        assertEquals("ACTIVE", result.getStatus());
        assertEquals(1L, result.getMemberId());
        assertEquals("Gold Monthly", result.getPlanName());
        assertNotNull(result.getStartDate());
        assertNotNull(result.getEndDate());
    }

    @Test
    void subscribe_ShouldThrowIllegalArgument_WhenMemberIdNull() {
        assertThrows(IllegalArgumentException.class,
            () -> planService.subscribe(null, "email@test.com", 1L));
    }

    @Test
    void cancelSubscription_ShouldSetStatusCancelled() {
        MemberSubscription sub = new MemberSubscription(1L, 1L, "m@test.com", 1L, "Gold", null, null, "ACTIVE");
        when(subRepository.findById(1L)).thenReturn(Optional.of(sub));
        when(subRepository.save(any())).thenReturn(sub);

        String result = planService.cancelSubscription(1L);

        assertEquals("CANCELLED", sub.getStatus());
        assertTrue(result.contains("cancelled"));
    }

    @Test
    void cancelSubscription_ShouldThrowSubscriptionNotFoundException_WhenNotFound() {
        when(subRepository.findById(99L)).thenReturn(Optional.empty());
        assertThrows(SubscriptionNotFoundException.class, () -> planService.cancelSubscription(99L));
    }
}
