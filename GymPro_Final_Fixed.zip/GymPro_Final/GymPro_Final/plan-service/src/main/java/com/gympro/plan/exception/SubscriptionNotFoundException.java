package com.gympro.plan.exception;
public class SubscriptionNotFoundException extends RuntimeException {
    public SubscriptionNotFoundException(String message) { super(message); }
}
