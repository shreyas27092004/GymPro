package com.gympro.plan.service;

import com.gympro.plan.entity.MembershipPlan;
import com.gympro.plan.entity.MemberSubscription;
import com.gympro.plan.exception.PlanNotFoundException;
import com.gympro.plan.exception.SubscriptionNotFoundException;
import com.gympro.plan.repository.MembershipPlanRepository;
import com.gympro.plan.repository.MemberSubscriptionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Slf4j
@Service
public class PlanService {

    @Autowired private MembershipPlanRepository planRepo;
    @Autowired private MemberSubscriptionRepository subRepo;

    @Transactional
    public MembershipPlan createPlan(MembershipPlan plan) {
        if (plan.getPlanName() == null || plan.getPlanName().isBlank())
            throw new IllegalArgumentException("Plan name is required");
        plan.setActive(true);
        if ("MONTHLY".equals(plan.getDurationType()))   plan.setDurationDays(30);
        if ("QUARTERLY".equals(plan.getDurationType())) plan.setDurationDays(90);
        if ("YEARLY".equals(plan.getDurationType()))    plan.setDurationDays(365);
        MembershipPlan saved = planRepo.save(plan);
        log.info("Plan created: id={}, name={}", saved.getId(), saved.getPlanName());
        return saved;
    }

    @Transactional(readOnly = true)
    public List<MembershipPlan> getAllPlans() {
        return planRepo.findAll();
    }

    @Transactional(readOnly = true)
    public List<MembershipPlan> getActivePlans() {
        return planRepo.findByActive(true);
    }

    @Transactional(readOnly = true)
    public MembershipPlan getPlanById(Long id) {
        return planRepo.findById(id)
            .orElseThrow(() -> new PlanNotFoundException("Plan not found: " + id));
    }

    @Transactional
    public MembershipPlan updatePlan(Long id, MembershipPlan updated) {
        MembershipPlan plan = getPlanById(id);
        plan.setPlanName(updated.getPlanName());
        plan.setDescription(updated.getDescription());
        plan.setPrice(updated.getPrice());
        return planRepo.save(plan);
    }

    @Transactional
    public String deactivatePlan(Long id) {
        MembershipPlan plan = getPlanById(id);
        plan.setActive(false);
        planRepo.save(plan);
        log.info("Plan deactivated: id={}", id);
        return "Plan deactivated";
    }

    @Transactional
    public MemberSubscription subscribe(Long memberId, String memberEmail, Long planId) {
        if (memberId == null) throw new IllegalArgumentException("memberId is required");
        if (memberEmail == null || memberEmail.isBlank()) throw new IllegalArgumentException("memberEmail is required");

        MembershipPlan plan = getPlanById(planId);

        LocalDate start = LocalDate.now();
        LocalDate end   = start.plusDays(plan.getDurationDays());

        MemberSubscription sub = new MemberSubscription();
        sub.setMemberId(memberId);
        sub.setMemberEmail(memberEmail);
        sub.setPlanId(planId);
        sub.setPlanName(plan.getPlanName());
        sub.setStartDate(start);
        sub.setEndDate(end);
        sub.setStatus("ACTIVE");

        MemberSubscription saved = subRepo.save(sub);
        log.info("Member {} subscribed to plan {}", memberId, planId);
        return saved;
    }

    @Transactional(readOnly = true)
    public List<MemberSubscription> getMySubscriptions(Long memberId) {
        return subRepo.findByMemberId(memberId);
    }

    @Transactional
    public String cancelSubscription(Long subId) {
        MemberSubscription sub = subRepo.findById(subId)
            .orElseThrow(() -> new SubscriptionNotFoundException("Subscription not found: " + subId));
        sub.setStatus("CANCELLED");
        subRepo.save(sub);
        log.info("Subscription cancelled: id={}", subId);
        return "Subscription cancelled";
    }
}
