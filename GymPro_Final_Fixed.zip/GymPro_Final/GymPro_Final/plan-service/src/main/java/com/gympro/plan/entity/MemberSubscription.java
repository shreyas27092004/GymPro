package com.gympro.plan.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

// ✅ Which plan has a member subscribed to?
@Entity
@Table(name = "member_subscriptions")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MemberSubscription {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long memberId;
    private String memberEmail;

    private Long planId;
    private String planName;

    private LocalDate startDate;
    private LocalDate endDate;
    private String status;          // ACTIVE | EXPIRED | CANCELLED
}
