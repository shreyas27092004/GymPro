package com.gympro.plan.controller;

import com.gympro.plan.entity.MembershipPlan;
import com.gympro.plan.entity.MemberSubscription;
import com.gympro.plan.service.PlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

// ✅ Role access:
//   POST /plans           → ADMIN (create plan)
//   GET  /plans           → ALL authenticated
//   POST /plans/subscribe → MEMBER
//   GET  /plans/my/{id}   → MEMBER (own)
@RestController
@RequestMapping("/plans")
public class PlanController {

    @Autowired
    private PlanService service;

    // ── Plan CRUD ──────────────────────────────────────────

    @PostMapping
    public MembershipPlan createPlan(@RequestBody MembershipPlan plan,
                                     @RequestHeader("X-User-Role") String role) {
        if (!"ADMIN".equals(role)) throw new RuntimeException("Access denied ❌ ADMIN only");
        return service.createPlan(plan);
    }

    @GetMapping
    public List<MembershipPlan> getAll() {
        return service.getActivePlans();
    }

    @GetMapping("/{id}")
    public MembershipPlan getById(@PathVariable Long id) {
        return service.getPlanById(id);
    }

    @PutMapping("/{id}")
    public MembershipPlan update(@PathVariable Long id, @RequestBody MembershipPlan plan,
                                  @RequestHeader("X-User-Role") String role) {
        if (!"ADMIN".equals(role)) throw new RuntimeException("Access denied ❌ ADMIN only");
        return service.updatePlan(id, plan);
    }

    @DeleteMapping("/{id}")
    public String deactivate(@PathVariable Long id,
                             @RequestHeader("X-User-Role") String role) {
        if (!"ADMIN".equals(role)) throw new RuntimeException("Access denied ❌ ADMIN only");
        return service.deactivatePlan(id);
    }

    // ── Subscription ───────────────────────────────────────

    // POST /plans/subscribe?memberId=1&memberEmail=abc@mail.com&planId=2
    @PostMapping("/subscribe")
    public MemberSubscription subscribe(@RequestParam Long memberId,
                                         @RequestParam String memberEmail,
                                         @RequestParam Long planId) {
        return service.subscribe(memberId, memberEmail, planId);
    }

    @GetMapping("/my/{memberId}")
    public List<MemberSubscription> myPlans(@PathVariable Long memberId) {
        return service.getMySubscriptions(memberId);
    }

    @DeleteMapping("/subscription/{subId}")
    public String cancel(@PathVariable Long subId) {
        return service.cancelSubscription(subId);
    }

    @GetMapping("/test")
    public String test() { return "Plan Service Working ✅"; }
}
