package com.gympro.plan.entity;

import jakarta.persistence.*;
import lombok.*;

// ✅ Plan catalog – ADMIN creates plans, MEMBERs subscribe
@Entity
@Table(name = "membership_plans")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MembershipPlan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String planName;        // e.g. "Gold Monthly"
    private String description;
    private String durationType;    // MONTHLY | QUARTERLY | YEARLY

    private double price;
    private int durationDays;       // 30, 90, 365
    private boolean active;
}
