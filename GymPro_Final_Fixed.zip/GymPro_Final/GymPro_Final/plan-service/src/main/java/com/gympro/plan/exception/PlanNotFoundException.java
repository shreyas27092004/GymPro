package com.gympro.plan.exception;
public class PlanNotFoundException extends RuntimeException {
    public PlanNotFoundException(String message) { super(message); }
}
