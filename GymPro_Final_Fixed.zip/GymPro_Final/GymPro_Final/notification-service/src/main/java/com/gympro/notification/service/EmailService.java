package com.gympro.notification.service;

import com.gympro.notification.exception.EmailException;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

// ✅ EmailService – sends REAL emails via Gmail SMTP
// Uses MimeMessage for HTML-formatted emails (looks professional)
@Slf4j
@Service
@Transactional
public class EmailService {

    // JavaMailSender is auto-configured by Spring Boot
    // from the spring.mail.* properties in application.properties
    @Autowired
    private JavaMailSender mailSender;

    // Sender email from application.properties
    @Value("${spring.mail.username}")
    private String fromEmail;

    // ─── MAIN METHOD ──────────────────────────────────────────────────────

    // Sends a plain-text email
    // Called from NotificationController when Feign clients call /notify/send
    public void sendEmail(String to, String subject, String body) {

        // Validate inputs before trying to send
        validateEmailInput(to, subject, body);

        try {
            // MimeMessage = email object (like composing in Gmail)
            MimeMessage mimeMessage = mailSender.createMimeMessage();

            // MimeMessageHelper = makes it easier to set To, Subject, Body
            // 2nd param = true means we're sending HTML content
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");

            helper.setFrom(fromEmail);          // From: your Gmail
            helper.setTo(to);                   // To: recipient
            helper.setSubject(subject);         // Subject line
            helper.setText(buildHtmlBody(subject, body), true);  // HTML body

            // Actually send the email
            mailSender.send(mimeMessage);

            log.info("✅ Email sent to: {} | Subject: {}", to, subject);

        } catch (MessagingException e) {
            // MessagingException = problem creating/formatting the email
            log.error("❌ Failed to create email for {}: {}", to, e.getMessage());
            throw new EmailException("Failed to create email: " + e.getMessage(), e);

        } catch (MailException e) {
            // MailException = problem connecting to Gmail SMTP / authentication failed
            log.error("❌ Failed to send email to {}: {}", to, e.getMessage());
            throw new EmailException("Failed to send email to " + to + ": " + e.getMessage(), e);
        }
    }

    // ─── SPECIFIC EMAIL TEMPLATES ─────────────────────────────────────────

    // Called when a booking is created – sent to the MEMBER
    public void sendBookingConfirmationToMember(String to, Long bookingId,
                                                 String trainerName, String day, String time) {
        String subject = "GymPro – Session Booked Successfully ✅";
        String body =
            "Your training session has been confirmed!

" +
            "Booking ID  : #" + bookingId + "
" +
            "Trainer     : " + trainerName + "
" +
            "Day         : " + day + "
" +
            "Time        : " + time + "

" +
            "Please arrive 5 minutes early. See you at the gym! 💪";
        sendEmail(to, subject, body);
    }

    // Called when a booking is created – sent to the TRAINER
    public void sendBookingNotificationToTrainer(String to, Long bookingId,
                                                  String memberName, String day, String time) {
        String subject = "GymPro – New Session Booking";
        String body =
            "You have a new training session booking!

" +
            "Booking ID  : #" + bookingId + "
" +
            "Member      : " + memberName + "
" +
            "Day         : " + day + "
" +
            "Time        : " + time + "

" +
            "Please confirm availability. Thank you!";
        sendEmail(to, subject, body);
    }

    // Called when a booking is cancelled
    public void sendCancellationEmail(String to, Long bookingId) {
        String subject = "GymPro – Booking Cancelled";
        String body =
            "Your booking #" + bookingId + " has been cancelled.

" +
            "If this was a mistake, please re-book through the app.
" +
            "We hope to see you soon! 🏋️";
        sendEmail(to, subject, body);
    }

    // Called after a successful payment
    public void sendPaymentReceipt(String to, Double amount, String method,
                                    String txnId, String description) {
        String subject = "GymPro – Payment Receipt 💳";
        String body =
            "Thank you for your payment!

" +
            "Amount      : ₹" + String.format("%.2f", amount) + "
" +
            "Method      : " + method + "
" +
            "Transaction : " + txnId + "
" +
            "Description : " + description + "

" +
            "This is your official payment receipt. Keep it safe.
" +
            "GymPro Team 💪";
        sendEmail(to, subject, body);
    }

    // Called when a refund is processed by ADMIN
    public void sendRefundEmail(String to, Double amount, String txnId) {
        String subject = "GymPro – Refund Processed 💰";
        String body =
            "Your refund has been processed!

" +
            "Refund Amount : ₹" + String.format("%.2f", amount) + "
" +
            "Transaction   : " + txnId + "

" +
            "The amount will reflect in 3-5 business days.
" +
            "GymPro Team";
        sendEmail(to, subject, body);
    }

    // Called when a member subscribes to a plan
    public void sendPlanSubscriptionEmail(String to, String planName,
                                           String startDate, String endDate) {
        String subject = "GymPro – Plan Activated! 🎉";
        String body =
            "Your membership plan has been activated!

" +
            "Plan        : " + planName + "
" +
            "Start Date  : " + startDate + "
" +
            "End Date    : " + endDate + "

" +
            "Welcome to GymPro! Make the most of your membership. 💪
" +
            "GymPro Team";
        sendEmail(to, subject, body);
    }

    // ─── PRIVATE HELPERS ─────────────────────────────────────────────────

    // Input validation before sending
    private void validateEmailInput(String to, String subject, String body) {
        if (to == null || to.isBlank()) {
            throw new IllegalArgumentException("Recipient email cannot be empty");
        }
        if (!to.contains("@")) {
            throw new IllegalArgumentException("Invalid email address: " + to);
        }
        if (subject == null || subject.isBlank()) {
            throw new IllegalArgumentException("Email subject cannot be empty");
        }
        if (body == null || body.isBlank()) {
            throw new IllegalArgumentException("Email body cannot be empty");
        }
    }

    // Wraps plain text in a simple branded HTML template
    // This makes the email look clean and professional in Gmail
    private String buildHtmlBody(String subject, String plainText) {
        // Convert newlines to <br> for HTML display
        String htmlBody = plainText.replace("
", "<br>");

        return "<!DOCTYPE html>" +
               "<html><body style='font-family:Arial,sans-serif; margin:0; padding:0; background:#f4f4f4;'>" +
               "<div style='max-width:600px; margin:30px auto; background:#ffffff; border-radius:8px; overflow:hidden; box-shadow:0 2px 10px rgba(0,0,0,0.1);'>" +

               // Header
               "<div style='background:#1A3A6B; padding:24px 32px;'>" +
               "<h1 style='color:#ffffff; margin:0; font-size:24px;'>GymPro</h1>" +
               "<p style='color:#D6E8F9; margin:4px 0 0; font-size:13px;'>Gym Membership & Trainer Management</p>" +
               "</div>" +

               // Body
               "<div style='padding:32px;'>" +
               "<h2 style='color:#1A3A6B; margin-top:0;'>" + subject + "</h2>" +
               "<p style='color:#333; line-height:1.7; font-size:15px;'>" + htmlBody + "</p>" +
               "</div>" +

               // Footer
               "<div style='background:#f8f9fa; padding:16px 32px; border-top:1px solid #e9ecef;'>" +
               "<p style='color:#6c757d; font-size:12px; margin:0;'>" +
               "This is an automated email from GymPro. Please do not reply.<br>" +
               "&copy; 2025 GymPro. All rights reserved." +
               "</p>" +
               "</div>" +

               "</div></body></html>";
    }
}
