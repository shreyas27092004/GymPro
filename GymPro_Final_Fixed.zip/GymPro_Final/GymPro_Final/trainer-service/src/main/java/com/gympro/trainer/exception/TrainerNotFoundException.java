package com.gympro.trainer.exception;
public class TrainerNotFoundException extends RuntimeException {
    public TrainerNotFoundException(String message) { super(message); }
}
