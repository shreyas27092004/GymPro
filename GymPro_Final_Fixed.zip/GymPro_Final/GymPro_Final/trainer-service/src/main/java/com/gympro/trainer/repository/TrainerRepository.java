package com.gympro.trainer.repository;

import com.gympro.trainer.entity.Trainer;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TrainerRepository extends JpaRepository<Trainer, Long> {
    List<Trainer> findBySpecialization(String specialization);
    List<Trainer> findByStatus(String status);
}
