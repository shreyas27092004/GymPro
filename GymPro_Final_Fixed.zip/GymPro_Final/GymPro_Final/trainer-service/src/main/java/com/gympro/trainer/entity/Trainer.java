package com.gympro.trainer.entity;

import jakarta.persistence.*;
import lombok.*;

// ✅ Trainer profile – ADMIN creates/manages trainers
@Entity
@Table(name = "trainers")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Trainer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @Column(unique = true, nullable = false)
    private String email;

    private String phone;
    private String specialization;   // e.g. "Weight Loss", "Yoga", "Cardio"
    private int experienceYears;
    private String status;           // ACTIVE | INACTIVE
}
