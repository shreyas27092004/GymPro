package com.gympro.trainer.service;

import com.gympro.trainer.entity.Trainer;
import com.gympro.trainer.entity.TrainerSchedule;
import com.gympro.trainer.exception.ScheduleNotFoundException;
import com.gympro.trainer.exception.TrainerNotFoundException;
import com.gympro.trainer.repository.TrainerRepository;
import com.gympro.trainer.repository.TrainerScheduleRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
public class TrainerService {

    @Autowired private TrainerRepository repo;
    @Autowired private TrainerScheduleRepository scheduleRepo;

    @Transactional
    public Trainer createTrainer(Trainer trainer) {
        if (trainer.getEmail() == null || trainer.getEmail().isBlank())
            throw new IllegalArgumentException("Email is required");
        trainer.setStatus("ACTIVE");
        Trainer saved = repo.save(trainer);
        log.info("Trainer created: id={}, email={}", saved.getId(), saved.getEmail());
        return saved;
    }

    @Transactional(readOnly = true)
    public List<Trainer> getAllTrainers() {
        return repo.findAll();
    }

    @Transactional(readOnly = true)
    public Trainer getTrainerById(Long id) {
        return repo.findById(id)
            .orElseThrow(() -> new TrainerNotFoundException("Trainer not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<Trainer> getBySpecialization(String spec) {
        return repo.findBySpecialization(spec);
    }

    @Transactional
    public Trainer updateTrainer(Long id, Trainer updated) {
        Trainer existing = getTrainerById(id);
        existing.setName(updated.getName());
        existing.setPhone(updated.getPhone());
        existing.setSpecialization(updated.getSpecialization());
        existing.setExperienceYears(updated.getExperienceYears());
        return repo.save(existing);
    }

    @Transactional
    public String deleteTrainer(Long id) {
        Trainer t = getTrainerById(id);
        t.setStatus("INACTIVE");
        repo.save(t);
        log.info("Trainer deactivated: id={}", id);
        return "Trainer deactivated";
    }

    @Transactional
    public TrainerSchedule addSchedule(TrainerSchedule schedule) {
        if (schedule.getTrainerId() == null)
            throw new IllegalArgumentException("trainerId is required");
        schedule.setAvailable(true);
        return scheduleRepo.save(schedule);
    }

    @Transactional(readOnly = true)
    public List<TrainerSchedule> getSchedule(Long trainerId) {
        return scheduleRepo.findByTrainerId(trainerId);
    }

    @Transactional(readOnly = true)
    public List<TrainerSchedule> getAvailableSlots(Long trainerId) {
        return scheduleRepo.findByTrainerIdAndAvailable(trainerId, true);
    }

    @Transactional
    public void markSlotBooked(Long scheduleId) {
        TrainerSchedule slot = scheduleRepo.findById(scheduleId)
            .orElseThrow(() -> new ScheduleNotFoundException("Schedule not found: " + scheduleId));
        slot.setAvailable(false);
        scheduleRepo.save(slot);
    }
}
