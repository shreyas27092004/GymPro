package com.gympro.trainer;

import com.gympro.trainer.entity.Trainer;
import com.gympro.trainer.entity.TrainerSchedule;
import com.gympro.trainer.exception.ScheduleNotFoundException;
import com.gympro.trainer.exception.TrainerNotFoundException;
import com.gympro.trainer.repository.TrainerRepository;
import com.gympro.trainer.repository.TrainerScheduleRepository;
import com.gympro.trainer.service.TrainerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class TrainerServiceTest {

    @Mock private TrainerRepository trainerRepository;
    @Mock private TrainerScheduleRepository scheduleRepository;
    @InjectMocks private TrainerService trainerService;

    private Trainer testTrainer;
    private TrainerSchedule testSchedule;

    @BeforeEach
    void setUp() {
        testTrainer = new Trainer(1L, "Test Trainer", "trainer@gympro.com", "9123456789", "Yoga", 5, "ACTIVE");
        testSchedule = new TrainerSchedule(1L, 1L, "MON", "09:00", "11:00", true);
    }

    @Test
    void createTrainer_ShouldSetActiveAndSave() {
        Trainer input = new Trainer(null, "New", "new@gympro.com", "000", "Cardio", 3, null);
        when(trainerRepository.save(any())).thenReturn(testTrainer);

        trainerService.createTrainer(input);

        assertEquals("ACTIVE", input.getStatus());
        verify(trainerRepository).save(input);
    }

    @Test
    void createTrainer_ShouldThrowIllegalArgument_WhenEmailBlank() {
        Trainer input = new Trainer(null, "Name", "", "000", "Yoga", 3, null);
        assertThrows(IllegalArgumentException.class, () -> trainerService.createTrainer(input));
        verify(trainerRepository, never()).save(any());
    }

    @Test
    void getTrainerById_ShouldReturn_WhenFound() {
        when(trainerRepository.findById(1L)).thenReturn(Optional.of(testTrainer));
        Trainer result = trainerService.getTrainerById(1L);
        assertEquals(1L, result.getId());
    }

    @Test
    void getTrainerById_ShouldThrowTrainerNotFoundException_WhenNotFound() {
        when(trainerRepository.findById(99L)).thenReturn(Optional.empty());
        assertThrows(TrainerNotFoundException.class, () -> trainerService.getTrainerById(99L));
    }

    @Test
    void getAllTrainers_ShouldReturnList() {
        when(trainerRepository.findAll()).thenReturn(Arrays.asList(testTrainer));
        List<Trainer> result = trainerService.getAllTrainers();
        assertEquals(1, result.size());
    }

    @Test
    void updateTrainer_ShouldUpdateFields() {
        Trainer updated = new Trainer(null, "Updated", null, "999", "Pilates", 8, null);
        when(trainerRepository.findById(1L)).thenReturn(Optional.of(testTrainer));
        when(trainerRepository.save(any())).thenReturn(testTrainer);

        trainerService.updateTrainer(1L, updated);

        assertEquals("Updated", testTrainer.getName());
        assertEquals("Pilates", testTrainer.getSpecialization());
        assertEquals(8, testTrainer.getExperienceYears());
    }

    @Test
    void deleteTrainer_ShouldSetStatusInactive() {
        when(trainerRepository.findById(1L)).thenReturn(Optional.of(testTrainer));
        when(trainerRepository.save(any())).thenReturn(testTrainer);

        String result = trainerService.deleteTrainer(1L);

        assertEquals("INACTIVE", testTrainer.getStatus());
        assertTrue(result.contains("deactivated"));
    }

    @Test
    void addSchedule_ShouldSetAvailableAndSave() {
        TrainerSchedule input = new TrainerSchedule(null, 1L, "TUE", "10:00", "12:00", false);
        when(scheduleRepository.save(any())).thenReturn(testSchedule);

        trainerService.addSchedule(input);

        assertTrue(input.isAvailable());
        verify(scheduleRepository).save(input);
    }

    @Test
    void addSchedule_ShouldThrowIllegalArgument_WhenTrainerIdNull() {
        TrainerSchedule input = new TrainerSchedule(null, null, "MON", "09:00", "11:00", false);
        assertThrows(IllegalArgumentException.class, () -> trainerService.addSchedule(input));
    }

    @Test
    void markSlotBooked_ShouldSetAvailableFalse() {
        when(scheduleRepository.findById(1L)).thenReturn(Optional.of(testSchedule));
        when(scheduleRepository.save(any())).thenReturn(testSchedule);

        trainerService.markSlotBooked(1L);

        assertFalse(testSchedule.isAvailable());
        verify(scheduleRepository).save(testSchedule);
    }

    @Test
    void markSlotBooked_ShouldThrowScheduleNotFoundException_WhenNotFound() {
        when(scheduleRepository.findById(99L)).thenReturn(Optional.empty());
        assertThrows(ScheduleNotFoundException.class, () -> trainerService.markSlotBooked(99L));
    }
}
