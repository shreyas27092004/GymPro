package com.gympro.auth.controller;

import com.gympro.auth.dto.AuthResponse;
import com.gympro.auth.dto.LoginRequest;
import com.gympro.auth.entity.User;
import com.gympro.auth.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private AuthService service;

    // POST /auth/register  – body: { name, email, password, role }
    @PostMapping("/register")
    public AuthResponse register(@RequestBody User user) {
        return service.register(user);
    }

    // POST /auth/login  – body: { email, password }
    @PostMapping("/login")
    public AuthResponse login(@RequestBody LoginRequest req) {
        return service.login(req);
    }

    @GetMapping("/test")
    public String test() {
        return "Auth Service Working ✅";
    }
}
