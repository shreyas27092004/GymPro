package com.gympro.auth.service;

import com.gympro.auth.dto.AuthResponse;
import com.gympro.auth.dto.LoginRequest;
import com.gympro.auth.entity.User;
import com.gympro.auth.exception.InvalidCredentialsException;
import com.gympro.auth.exception.UserAlreadyExistsException;
import com.gympro.auth.exception.UserNotFoundException;
import com.gympro.auth.repository.UserRepository;
import com.gympro.auth.util.JwtUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
public class AuthService {

    @Autowired private UserRepository repo;
    @Autowired private JwtUtil jwtUtil;
    @Autowired private PasswordEncoder encoder;

    @Transactional
    public AuthResponse register(User user) {
        if (user.getEmail() == null || user.getEmail().isBlank())
            throw new IllegalArgumentException("Email is required");
        if (user.getPassword() == null || user.getPassword().isBlank())
            throw new IllegalArgumentException("Password is required");
        if (repo.existsByEmail(user.getEmail()))
            throw new UserAlreadyExistsException("Email already registered: " + user.getEmail());

        if (user.getRole() == null || user.getRole().isBlank())
            user.setRole("MEMBER");

        user.setPassword(encoder.encode(user.getPassword()));
        User saved = repo.save(user);
        log.info("User registered: email={}, role={}", saved.getEmail(), saved.getRole());
        String token = jwtUtil.generateToken(saved.getEmail(), saved.getRole());
        return new AuthResponse(token, saved.getEmail(), saved.getRole(), "Registered successfully");
    }

    @Transactional(readOnly = true)
    public AuthResponse login(LoginRequest req) {
        if (req.getEmail() == null || req.getEmail().isBlank())
            throw new IllegalArgumentException("Email is required");
        if (req.getPassword() == null || req.getPassword().isBlank())
            throw new IllegalArgumentException("Password is required");

        User user = repo.findByEmail(req.getEmail())
            .orElseThrow(() -> new UserNotFoundException("User not found: " + req.getEmail()));

        if (!encoder.matches(req.getPassword(), user.getPassword()))
            throw new InvalidCredentialsException("Invalid password for: " + req.getEmail());

        log.info("User logged in: email={}", user.getEmail());
        String token = jwtUtil.generateToken(user.getEmail(), user.getRole());
        return new AuthResponse(token, user.getEmail(), user.getRole(), "Login successful");
    }
}
