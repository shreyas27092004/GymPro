package com.gympro.auth;

import com.gympro.auth.dto.AuthResponse;
import com.gympro.auth.dto.LoginRequest;
import com.gympro.auth.entity.User;
import com.gympro.auth.exception.InvalidCredentialsException;
import com.gympro.auth.exception.UserAlreadyExistsException;
import com.gympro.auth.exception.UserNotFoundException;
import com.gympro.auth.repository.UserRepository;
import com.gympro.auth.service.AuthService;
import com.gympro.auth.util.JwtUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AuthServiceTest {

    @Mock private UserRepository userRepository;
    @Mock private JwtUtil jwtUtil;
    @Mock private PasswordEncoder passwordEncoder;
    @InjectMocks private AuthService authService;

    private User testUser;

    @BeforeEach
    void setUp() {
        testUser = new User(1L, "Test User", "test@gympro.com", "encodedPassword", "MEMBER");
    }

    @Test
    void register_ShouldReturnToken_WhenValidUser() {
        User newUser = new User(null, "New User", "new@gympro.com", "plainPass", "MEMBER");
        when(userRepository.existsByEmail("new@gympro.com")).thenReturn(false);
        when(passwordEncoder.encode("plainPass")).thenReturn("encodedPassword");
        when(userRepository.save(any(User.class))).thenReturn(testUser);
        when(jwtUtil.generateToken(anyString(), anyString())).thenReturn("jwt-token");

        AuthResponse response = authService.register(newUser);

        assertNotNull(response);
        assertEquals("jwt-token", response.getToken());
        verify(userRepository).save(any(User.class));
    }

    @Test
    void register_ShouldThrowUserAlreadyExistsException_WhenEmailExists() {
        User newUser = new User(null, "Dup", "test@gympro.com", "pass", "MEMBER");
        when(userRepository.existsByEmail("test@gympro.com")).thenReturn(true);

        assertThrows(UserAlreadyExistsException.class, () -> authService.register(newUser));
        verify(userRepository, never()).save(any());
    }

    @Test
    void register_ShouldDefaultToMemberRole_WhenRoleIsNull() {
        User newUser = new User(null, "New", "new@gympro.com", "pass", null);
        when(userRepository.existsByEmail("new@gympro.com")).thenReturn(false);
        when(passwordEncoder.encode(anyString())).thenReturn("encoded");
        when(userRepository.save(any())).thenAnswer(inv -> {
            User u = inv.getArgument(0); u.setId(1L); return u;
        });
        when(jwtUtil.generateToken(anyString(), anyString())).thenReturn("token");

        AuthResponse response = authService.register(newUser);
        assertEquals("MEMBER", response.getRole());
    }

    @Test
    void register_ShouldThrowIllegalArgument_WhenEmailBlank() {
        User newUser = new User(null, "User", "", "pass", "MEMBER");
        assertThrows(IllegalArgumentException.class, () -> authService.register(newUser));
    }

    @Test
    void login_ShouldReturnToken_WhenCredentialsValid() {
        LoginRequest req = new LoginRequest();
        req.setEmail("test@gympro.com");
        req.setPassword("plainPass");

        when(userRepository.findByEmail("test@gympro.com")).thenReturn(Optional.of(testUser));
        when(passwordEncoder.matches("plainPass", "encodedPassword")).thenReturn(true);
        when(jwtUtil.generateToken("test@gympro.com", "MEMBER")).thenReturn("jwt-token");

        AuthResponse response = authService.login(req);

        assertNotNull(response);
        assertEquals("jwt-token", response.getToken());
    }

    @Test
    void login_ShouldThrowUserNotFoundException_WhenEmailNotFound() {
        LoginRequest req = new LoginRequest();
        req.setEmail("unknown@gympro.com");
        req.setPassword("pass");
        when(userRepository.findByEmail("unknown@gympro.com")).thenReturn(Optional.empty());

        assertThrows(UserNotFoundException.class, () -> authService.login(req));
    }

    @Test
    void login_ShouldThrowInvalidCredentialsException_WhenPasswordWrong() {
        LoginRequest req = new LoginRequest();
        req.setEmail("test@gympro.com");
        req.setPassword("wrong");

        when(userRepository.findByEmail("test@gympro.com")).thenReturn(Optional.of(testUser));
        when(passwordEncoder.matches("wrong", "encodedPassword")).thenReturn(false);

        assertThrows(InvalidCredentialsException.class, () -> authService.login(req));
    }

    @Test
    void login_ShouldThrowIllegalArgument_WhenEmailBlank() {
        LoginRequest req = new LoginRequest();
        req.setEmail("  ");
        req.setPassword("pass");
        assertThrows(IllegalArgumentException.class, () -> authService.login(req));
    }
}
