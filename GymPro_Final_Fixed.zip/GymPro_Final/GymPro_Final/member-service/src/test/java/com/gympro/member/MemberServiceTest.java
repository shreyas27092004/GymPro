package com.gympro.member;

import com.gympro.member.entity.Member;
import com.gympro.member.repository.MemberRepository;
import com.gympro.member.service.MemberService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class MemberServiceTest {

    @Mock private MemberRepository memberRepository;
    @InjectMocks private MemberService memberService;

    private Member testMember;

    @BeforeEach
    void setUp() {
        testMember = new Member(1L, "Test Member", "member@gympro.com", "9876543210", "Bangalore", "MALE", "ACTIVE");
    }

    @Test
    void createMember_ShouldSaveAndSetActiveStatus() {
        Member input = new Member(null, "New", "new@gympro.com", "123", null, "FEMALE", null);
        when(memberRepository.save(any(Member.class))).thenReturn(testMember);

        memberService.createMember(input);

        assertEquals("ACTIVE", input.getStatus());
        verify(memberRepository).save(input);
    }

    @Test
    void createMember_ShouldThrowIllegalArgument_WhenEmailBlank() {
        Member input = new Member(null, "Name", "", "123", null, "MALE", null);
        assertThrows(IllegalArgumentException.class, () -> memberService.createMember(input));
        verify(memberRepository, never()).save(any());
    }

    @Test
    void getAllMembers_ShouldReturnList() {
        when(memberRepository.findAll()).thenReturn(Arrays.asList(testMember));
        List<Member> result = memberService.getAllMembers();
        assertEquals(1, result.size());
    }

    @Test
    void getMemberById_ShouldReturnMember_WhenFound() {
        when(memberRepository.findById(1L)).thenReturn(Optional.of(testMember));
        Member result = memberService.getMemberById(1L);
        assertEquals(1L, result.getId());
    }

    @Test
    void getMemberById_ShouldThrow_WhenNotFound() {
        when(memberRepository.findById(99L)).thenReturn(Optional.empty());
        assertThrows(RuntimeException.class, () -> memberService.getMemberById(99L));
    }

    @Test
    void updateMember_ShouldUpdateFields() {
        Member updated = new Member(null, "Updated", null, "9999999999", "New Addr", "MALE", null);
        when(memberRepository.findById(1L)).thenReturn(Optional.of(testMember));
        when(memberRepository.save(any())).thenReturn(testMember);

        memberService.updateMember(1L, updated);

        assertEquals("Updated", testMember.getName());
        assertEquals("9999999999", testMember.getPhone());
        verify(memberRepository).save(testMember);
    }

    @Test
    void deleteMember_ShouldSetStatusInactive() {
        when(memberRepository.findById(1L)).thenReturn(Optional.of(testMember));
        when(memberRepository.save(any())).thenReturn(testMember);

        String result = memberService.deleteMember(1L);

        assertEquals("INACTIVE", testMember.getStatus());
        assertTrue(result.contains("deactivated"));
    }

    @Test
    void deleteMember_ShouldThrow_WhenNotFound() {
        when(memberRepository.findById(99L)).thenReturn(Optional.empty());
        assertThrows(RuntimeException.class, () -> memberService.deleteMember(99L));
    }
}
