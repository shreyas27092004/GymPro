package com.gympro.member.controller;

import com.gympro.member.entity.Member;
import com.gympro.member.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

// ✅ Role access:
//   GET /members       → ADMIN
//   POST /members      → ADMIN or self-registration
//   GET /members/{id}  → MEMBER (own), ADMIN
//   PUT /members/{id}  → MEMBER (own), ADMIN
//   DELETE /members/{id} → ADMIN
@RestController
@RequestMapping("/members")
public class MemberController {

    @Autowired
    private MemberService service;

    @PostMapping
    public Member create(@RequestBody Member member) {
        return service.createMember(member);
    }

    @GetMapping
    public List<Member> getAll(@RequestHeader("X-User-Role") String role) {
        if (!"ADMIN".equals(role)) throw new RuntimeException("Access denied ❌ ADMIN only");
        return service.getAllMembers();
    }

    @GetMapping("/{id}")
    public Member getById(@PathVariable Long id) {
        return service.getMemberById(id);
    }

    @PutMapping("/{id}")
    public Member update(@PathVariable Long id, @RequestBody Member member) {
        return service.updateMember(id, member);
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable Long id,
                         @RequestHeader("X-User-Role") String role) {
        if (!"ADMIN".equals(role)) throw new RuntimeException("Access denied ❌ ADMIN only");
        return service.deleteMember(id);
    }

    @GetMapping("/test")
    public String test() { return "Member Service Working ✅"; }
}
