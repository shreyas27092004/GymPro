package com.gympro.member.service;

import com.gympro.member.entity.Member;
import com.gympro.member.repository.MemberRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
public class MemberService {

    @Autowired
    private MemberRepository repo;

    @Transactional
    public Member createMember(Member member) {
        if (member.getEmail() == null || member.getEmail().isBlank())
            throw new IllegalArgumentException("Email is required");
        member.setStatus("ACTIVE");
        Member saved = repo.save(member);
        log.info("Member created: id={}, email={}", saved.getId(), saved.getEmail());
        return saved;
    }

    @Transactional(readOnly = true)
    public List<Member> getAllMembers() {
        return repo.findAll();
    }

    @Transactional(readOnly = true)
    public Member getMemberById(Long id) {
        return repo.findById(id)
            .orElseThrow(() -> new RuntimeException("Member not found: " + id));
    }

    @Transactional
    public Member updateMember(Long id, Member updated) {
        Member existing = getMemberById(id);
        existing.setName(updated.getName());
        existing.setPhone(updated.getPhone());
        existing.setAddress(updated.getAddress());
        existing.setGender(updated.getGender());
        return repo.save(existing);
    }

    @Transactional
    public String deleteMember(Long id) {
        Member member = getMemberById(id);
        member.setStatus("INACTIVE");
        repo.save(member);
        log.info("Member deactivated: id={}", id);
        return "Member deactivated";
    }
}
