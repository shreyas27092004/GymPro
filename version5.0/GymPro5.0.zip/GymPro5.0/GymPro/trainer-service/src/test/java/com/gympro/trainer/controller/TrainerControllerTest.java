package com.gympro.trainer.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gympro.trainer.entity.Trainer;
import com.gympro.trainer.entity.TrainerSchedule;
import com.gympro.trainer.exception.AccessDeniedException;
import com.gympro.trainer.exception.GlobalExceptionHandler;
import com.gympro.trainer.service.TrainerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("TrainerController Unit Tests")
class TrainerControllerTest {

    private MockMvc mockMvc;

    @Mock
    private TrainerService trainerService;

    @InjectMocks
    private TrainerController trainerController;

    private final ObjectMapper objectMapper = new ObjectMapper();

    private Trainer sampleTrainer;
    private TrainerSchedule sampleSchedule;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders
                .standaloneSetup(trainerController)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();

        sampleTrainer = new Trainer();
        sampleTrainer.setId(1L);
        sampleTrainer.setName("John Doe");
        sampleTrainer.setEmail("john@gym.com");
        sampleTrainer.setPhone("9876543210");
        sampleTrainer.setSpecialization("Yoga");
        sampleTrainer.setExperienceYears(5);
        sampleTrainer.setStatus("ACTIVE");

        sampleSchedule = new TrainerSchedule();
        sampleSchedule.setId(1L);
        sampleSchedule.setTrainerId(1L);
        sampleSchedule.setSessionDate(java.time.LocalDate.now().plusDays(5));
        sampleSchedule.setStartTime("09:00");
        sampleSchedule.setEndTime("11:00");
        sampleSchedule.setMaxCapacity(20);
        sampleSchedule.setBookedCount(0);
        sampleSchedule.setCancelled(false);
        sampleSchedule.setAvailable(true);
    }

    // ── POST /trainers ──────────────────────────────────────────

    @Test
    @DisplayName("POST /trainers - ADMIN role should create trainer successfully")
    void createTrainer_asAdmin_shouldReturn200() throws Exception {
        when(trainerService.createTrainer(any(Trainer.class))).thenReturn(sampleTrainer);

        mockMvc.perform(post("/trainers")
                        .header("X-User-Role", "ADMIN")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(sampleTrainer)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("John Doe"))
                .andExpect(jsonPath("$.email").value("john@gym.com"));

        verify(trainerService, times(1)).createTrainer(any(Trainer.class));
    }

    @Test
    @DisplayName("POST /trainers - non-ADMIN role should throw AccessDeniedException → 403")
    void createTrainer_asNonAdmin_shouldReturn403() throws Exception {
        // Controller throws AccessDeniedException before calling service when role != ADMIN
        mockMvc.perform(post("/trainers")
                        .header("X-User-Role", "MEMBER")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(sampleTrainer)))
                .andExpect(status().isForbidden());

        verify(trainerService, never()).createTrainer(any());
    }

    @Test
    @DisplayName("POST /trainers - TRAINER role should return 403")
    void createTrainer_asTrainer_shouldReturn403() throws Exception {
        mockMvc.perform(post("/trainers")
                        .header("X-User-Role", "TRAINER")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(sampleTrainer)))
                .andExpect(status().isForbidden());
    }

    // ── GET /trainers/pending, PATCH .../approve, .../reject ─────

    @Test
    @DisplayName("GET /trainers/pending - ADMIN role should return the pending list")
    void getPending_asAdmin_shouldReturn200() throws Exception {
        Trainer pending = new Trainer();
        pending.setId(2L);
        pending.setStatus("PENDING");
        when(trainerService.getPendingTrainers()).thenReturn(Arrays.asList(pending));

        mockMvc.perform(get("/trainers/pending").header("X-User-Role", "ADMIN"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1))
                .andExpect(jsonPath("$[0].status").value("PENDING"));

        verify(trainerService, times(1)).getPendingTrainers();
    }

    @Test
    @DisplayName("GET /trainers/pending - non-ADMIN role should return 403")
    void getPending_asNonAdmin_shouldReturn403() throws Exception {
        mockMvc.perform(get("/trainers/pending").header("X-User-Role", "TRAINER"))
                .andExpect(status().isForbidden());

        verify(trainerService, never()).getPendingTrainers();
    }

    @Test
    @DisplayName("PATCH /trainers/{id}/approve - ADMIN role should approve the trainer")
    void approveTrainer_asAdmin_shouldReturn200() throws Exception {
        sampleTrainer.setStatus("ACTIVE");
        when(trainerService.approveTrainer(1L)).thenReturn(sampleTrainer);

        mockMvc.perform(patch("/trainers/1/approve").header("X-User-Role", "ADMIN"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("ACTIVE"));

        verify(trainerService, times(1)).approveTrainer(1L);
    }

    @Test
    @DisplayName("PATCH /trainers/{id}/approve - non-ADMIN role should return 403")
    void approveTrainer_asNonAdmin_shouldReturn403() throws Exception {
        mockMvc.perform(patch("/trainers/1/approve").header("X-User-Role", "TRAINER"))
                .andExpect(status().isForbidden());

        verify(trainerService, never()).approveTrainer(anyLong());
    }

    @Test
    @DisplayName("PATCH /trainers/{id}/reject - ADMIN role should reject the trainer")
    void rejectTrainer_asAdmin_shouldReturn200() throws Exception {
        sampleTrainer.setStatus("REJECTED");
        when(trainerService.rejectTrainer(1L)).thenReturn(sampleTrainer);

        mockMvc.perform(patch("/trainers/1/reject").header("X-User-Role", "ADMIN"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("REJECTED"));

        verify(trainerService, times(1)).rejectTrainer(1L);
    }

    @Test
    @DisplayName("PATCH /trainers/{id}/reject - non-ADMIN role should return 403")
    void rejectTrainer_asNonAdmin_shouldReturn403() throws Exception {
        mockMvc.perform(patch("/trainers/1/reject").header("X-User-Role", "MEMBER"))
                .andExpect(status().isForbidden());

        verify(trainerService, never()).rejectTrainer(anyLong());
    }

    // ── GET /trainers ───────────────────────────────────────────

    @Test
    @DisplayName("GET /trainers - should return list of all trainers")
    void getAllTrainers_shouldReturnList() throws Exception {
        List<Trainer> trainers = Arrays.asList(sampleTrainer);
        when(trainerService.getAllTrainers()).thenReturn(trainers);

        mockMvc.perform(get("/trainers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1))
                .andExpect(jsonPath("$[0].name").value("John Doe"));

        verify(trainerService, times(1)).getAllTrainers();
    }

    @Test
    @DisplayName("GET /trainers - should return empty list when no trainers exist")
    void getAllTrainers_shouldReturnEmptyList() throws Exception {
        when(trainerService.getAllTrainers()).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/trainers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(0));
    }

    // ── GET /trainers/{id} ──────────────────────────────────────

    @Test
    @DisplayName("GET /trainers/{id} - should return trainer by id")
    void getById_shouldReturnTrainer() throws Exception {
        when(trainerService.getTrainerById(1L)).thenReturn(sampleTrainer);

        mockMvc.perform(get("/trainers/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.specialization").value("Yoga"));
    }

    // ── GET /trainers/specialization/{spec} ─────────────────────

    @Test
    @DisplayName("GET /trainers/specialization/{spec} - should return matching trainers")
    void getBySpec_shouldReturnFilteredList() throws Exception {
        when(trainerService.getBySpecialization("Yoga")).thenReturn(Arrays.asList(sampleTrainer));

        mockMvc.perform(get("/trainers/specialization/Yoga"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1))
                .andExpect(jsonPath("$[0].specialization").value("Yoga"));
    }

    @Test
    @DisplayName("GET /trainers/specialization/{spec} - no match returns empty list")
    void getBySpec_noMatch_shouldReturnEmpty() throws Exception {
        when(trainerService.getBySpecialization("Boxing")).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/trainers/specialization/Boxing"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(0));
    }

    // ── PUT /trainers/{id} ──────────────────────────────────────

    @Test
    @DisplayName("PUT /trainers/{id} - should update trainer and return updated")
    void updateTrainer_shouldReturnUpdatedTrainer() throws Exception {
        Trainer updated = new Trainer();
        updated.setId(1L);
        updated.setName("Jane Updated");
        updated.setSpecialization("Cardio");
        updated.setExperienceYears(8);

        when(trainerService.updateTrainer(eq(1L), any(Trainer.class))).thenReturn(updated);

        mockMvc.perform(put("/trainers/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updated)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Jane Updated"))
                .andExpect(jsonPath("$.specialization").value("Cardio"));
    }

    // ── DELETE /trainers/{id} ───────────────────────────────────

    @Test
    @DisplayName("DELETE /trainers/{id} - ADMIN role should deactivate trainer")
    void deleteTrainer_asAdmin_shouldReturnSuccessMessage() throws Exception {
        when(trainerService.deleteTrainer(1L)).thenReturn("Trainer deactivated ✅");

        mockMvc.perform(delete("/trainers/1")
                        .header("X-User-Role", "ADMIN"))
                .andExpect(status().isOk())
                .andExpect(content().string("Trainer deactivated ✅"));
    }

    @Test
    @DisplayName("DELETE /trainers/{id} - MEMBER role should return 403")
    void deleteTrainer_asMember_shouldReturn403() throws Exception {
        mockMvc.perform(delete("/trainers/1")
                        .header("X-User-Role", "MEMBER"))
                .andExpect(status().isForbidden());

        verify(trainerService, never()).deleteTrainer(anyLong());
    }

    @Test
    @DisplayName("DELETE /trainers/{id} - TRAINER role should return 403")
    void deleteTrainer_asTrainer_shouldReturn403() throws Exception {
        mockMvc.perform(delete("/trainers/1")
                        .header("X-User-Role", "TRAINER"))
                .andExpect(status().isForbidden());

        verify(trainerService, never()).deleteTrainer(anyLong());
    }

    // ── POST /trainers/schedule ─────────────────────────────────

    @Test
    @DisplayName("POST /trainers/schedule - TRAINER role should add schedule")
    void addSchedule_asTrainer_shouldReturnSchedule() throws Exception {
        when(trainerService.addSchedule(any(TrainerSchedule.class))).thenReturn(sampleSchedule);

        mockMvc.perform(post("/trainers/schedule")
                        .header("X-User-Role", "TRAINER")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(sampleSchedule)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.maxCapacity").value(20))
                .andExpect(jsonPath("$.available").value(true));
    }

    @Test
    @DisplayName("POST /trainers/schedule - ADMIN role should add schedule")
    void addSchedule_asAdmin_shouldReturnSchedule() throws Exception {
        when(trainerService.addSchedule(any(TrainerSchedule.class))).thenReturn(sampleSchedule);

        mockMvc.perform(post("/trainers/schedule")
                        .header("X-User-Role", "ADMIN")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(sampleSchedule)))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("POST /trainers/schedule - MEMBER role should return 403")
    void addSchedule_asMember_shouldReturn403() throws Exception {
        mockMvc.perform(post("/trainers/schedule")
                        .header("X-User-Role", "MEMBER")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(sampleSchedule)))
                .andExpect(status().isForbidden());

        verify(trainerService, never()).addSchedule(any());
    }

    // ── GET /trainers/{id}/schedule ────────────────────────────

    @Test
    @DisplayName("GET /trainers/{id}/schedule - should return all schedule slots")
    void getSchedule_shouldReturnScheduleList() throws Exception {
        when(trainerService.getSchedule(1L)).thenReturn(Arrays.asList(sampleSchedule));

        mockMvc.perform(get("/trainers/1/schedule"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1))
                .andExpect(jsonPath("$[0].startTime").value("09:00"));
    }

    // ── GET /trainers/{id}/available-slots ─────────────────────

    @Test
    @DisplayName("GET /trainers/{id}/available-slots - should return only available slots")
    void getAvailableSlots_shouldReturnOnlyAvailable() throws Exception {
        when(trainerService.getAvailableSlots(1L)).thenReturn(Arrays.asList(sampleSchedule));

        mockMvc.perform(get("/trainers/1/available-slots"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1))
                .andExpect(jsonPath("$[0].available").value(true));
    }

    // ── PUT /trainers/schedule/{scheduleId}/book ────────────────

    @Test
    @DisplayName("PUT /trainers/schedule/{scheduleId}/book - should mark slot as booked")
    void markBooked_shouldReturnSuccessMessage() throws Exception {
        doNothing().when(trainerService).markSlotBooked(1L);

        mockMvc.perform(put("/trainers/schedule/1/book"))
                .andExpect(status().isOk())
                .andExpect(content().string("Slot marked as booked ✅"));

        verify(trainerService, times(1)).markSlotBooked(1L);
    }

    @Test
    @DisplayName("POST /trainers/schedule - duplicate session should return 409")
    void addSchedule_duplicate_shouldReturn409() throws Exception {
        when(trainerService.addSchedule(any(TrainerSchedule.class)))
            .thenThrow(new com.gympro.trainer.exception.DuplicateScheduleException(
                "Trainer #1 already has a session scheduled on 2026-07-15 at 09:00"));

        mockMvc.perform(post("/trainers/schedule")
                        .header("X-User-Role", "TRAINER")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(sampleSchedule)))
                .andExpect(status().isConflict());
    }

    // ── GET /trainers/schedule/{scheduleId} ─────────────────────

    @Test
    @DisplayName("GET /trainers/schedule/{scheduleId} - should return the schedule slot")
    void getScheduleById_shouldReturnSchedule() throws Exception {
        when(trainerService.getScheduleById(1L)).thenReturn(sampleSchedule);

        mockMvc.perform(get("/trainers/schedule/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.maxCapacity").value(20));
    }

    // ── PUT /trainers/schedule/{scheduleId}/unbook ──────────────

    @Test
    @DisplayName("PUT /trainers/schedule/{scheduleId}/unbook - should release the slot")
    void unbook_shouldReturnSuccessMessage() throws Exception {
        doNothing().when(trainerService).unbookSlot(1L);

        mockMvc.perform(put("/trainers/schedule/1/unbook"))
                .andExpect(status().isOk())
                .andExpect(content().string("Slot released ✅"));

        verify(trainerService, times(1)).unbookSlot(1L);
    }

    // ── PATCH /trainers/schedule/{scheduleId}/cancel ────────────

    @Test
    @DisplayName("PATCH /trainers/schedule/{scheduleId}/cancel - TRAINER role should cancel session")
    void cancelSchedule_asTrainer_shouldReturn200() throws Exception {
        sampleSchedule.setCancelled(true);
        sampleSchedule.setAvailable(false);
        when(trainerService.cancelSchedule(1L)).thenReturn(sampleSchedule);

        mockMvc.perform(patch("/trainers/schedule/1/cancel").header("X-User-Role", "TRAINER"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.cancelled").value(true));

        verify(trainerService, times(1)).cancelSchedule(1L);
    }

    @Test
    @DisplayName("PATCH /trainers/schedule/{scheduleId}/cancel - MEMBER role should return 403")
    void cancelSchedule_asMember_shouldReturn403() throws Exception {
        mockMvc.perform(patch("/trainers/schedule/1/cancel").header("X-User-Role", "MEMBER"))
                .andExpect(status().isForbidden());

        verify(trainerService, never()).cancelSchedule(anyLong());
    }

    // ── GET /trainers/by-email/{email} ──────────────────────────

    @Test
    @DisplayName("GET /trainers/by-email/{email} - should return trainer when found")
    void getByEmail_shouldReturnTrainer() throws Exception {
        when(trainerService.getByEmail("john@gym.com")).thenReturn(sampleTrainer);

        mockMvc.perform(get("/trainers/by-email/john@gym.com"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.email").value("john@gym.com"));
    }

    @Test
    @DisplayName("GET /trainers/by-email/{email} - should return 404 when not found")
    void getByEmail_shouldReturn404_whenNotFound() throws Exception {
        when(trainerService.getByEmail("missing@gym.com"))
                .thenThrow(new com.gympro.trainer.exception.TrainerNotFoundException("Trainer not found with email: missing@gym.com"));

        mockMvc.perform(get("/trainers/by-email/missing@gym.com"))
                .andExpect(status().isNotFound());
    }

    // ── PATCH /trainers/{id}/session-fee ────────────────────────

    @Test
    @DisplayName("PATCH /trainers/{id}/session-fee - TRAINER role should update fee")
    void updateSessionFee_asTrainer_shouldReturn200() throws Exception {
        Trainer updated = new Trainer();
        updated.setId(1L);
        updated.setSessionFee(new java.math.BigDecimal("500.00"));
        when(trainerService.updateSessionFee(eq(1L), any())).thenReturn(updated);

        mockMvc.perform(patch("/trainers/1/session-fee")
                        .header("X-User-Role", "TRAINER")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"sessionFee\": 500.00}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.sessionFee").value(500.00));
    }

    @Test
    @DisplayName("PATCH /trainers/{id}/session-fee - ADMIN role should update fee")
    void updateSessionFee_asAdmin_shouldReturn200() throws Exception {
        Trainer updated = new Trainer();
        updated.setId(1L);
        updated.setSessionFee(new java.math.BigDecimal("500.00"));
        when(trainerService.updateSessionFee(eq(1L), any())).thenReturn(updated);

        mockMvc.perform(patch("/trainers/1/session-fee")
                        .header("X-User-Role", "ADMIN")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"sessionFee\": 500.00}"))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("PATCH /trainers/{id}/session-fee - MEMBER role should return 403")
    void updateSessionFee_asMember_shouldReturn403() throws Exception {
        mockMvc.perform(patch("/trainers/1/session-fee")
                        .header("X-User-Role", "MEMBER")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"sessionFee\": 500.00}"))
                .andExpect(status().isForbidden());

        verify(trainerService, never()).updateSessionFee(anyLong(), any());
    }

    @Test
    @DisplayName("PATCH /trainers/{id}/session-fee - missing sessionFee field should return 400")
    void updateSessionFee_missingFeeField_shouldReturn400() throws Exception {
        mockMvc.perform(patch("/trainers/1/session-fee")
                        .header("X-User-Role", "TRAINER")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}"))
                .andExpect(status().isBadRequest());

        verify(trainerService, never()).updateSessionFee(anyLong(), any());
    }

    // ── DELETE /trainers/schedule/{scheduleId} ──────────────────

    @Test
    @DisplayName("DELETE /trainers/schedule/{scheduleId} - TRAINER role should delete slot")
    void deleteSchedule_asTrainer_shouldReturn200() throws Exception {
        when(trainerService.deleteSchedule(1L)).thenReturn("Schedule slot deleted ✅");

        mockMvc.perform(delete("/trainers/schedule/1")
                        .header("X-User-Role", "TRAINER"))
                .andExpect(status().isOk())
                .andExpect(content().string("Schedule slot deleted ✅"));
    }

    @Test
    @DisplayName("DELETE /trainers/schedule/{scheduleId} - ADMIN role should delete slot")
    void deleteSchedule_asAdmin_shouldReturn200() throws Exception {
        when(trainerService.deleteSchedule(1L)).thenReturn("Schedule slot deleted ✅");

        mockMvc.perform(delete("/trainers/schedule/1")
                        .header("X-User-Role", "ADMIN"))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("DELETE /trainers/schedule/{scheduleId} - MEMBER role should return 403")
    void deleteSchedule_asMember_shouldReturn403() throws Exception {
        mockMvc.perform(delete("/trainers/schedule/1")
                        .header("X-User-Role", "MEMBER"))
                .andExpect(status().isForbidden());

        verify(trainerService, never()).deleteSchedule(anyLong());
    }

    @Test
    @DisplayName("DELETE /trainers/schedule/{scheduleId} - slot with bookings should return 409")
    void deleteSchedule_bookedSlot_shouldReturn409() throws Exception {
        when(trainerService.deleteSchedule(1L))
                .thenThrow(new IllegalStateException("Cannot delete a slot with existing bookings. Slot #1 currently has 2 member(s) booked."));

        mockMvc.perform(delete("/trainers/schedule/1")
                        .header("X-User-Role", "ADMIN"))
                .andExpect(status().isConflict());
    }

    // ── GET /trainers/test ──────────────────────────────────────

    @Test
    @DisplayName("GET /trainers/test - should return health check message")
    void test_shouldReturnHealthMessage() throws Exception {
        mockMvc.perform(get("/trainers/test"))
                .andExpect(status().isOk())
                .andExpect(content().string("Trainer Service Working ✅"));
    }
}
