package com.gympro.chatbot.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import java.util.List;

/**
 * Configures the RestTemplate used to call the OpenAI API.
 *
 * openAiRestTemplate — pre-configured with:
 *   • Authorization: Bearer {openAiApiKey} header on every request
 *   • 10-second connect timeout
 *   • 30-second read timeout (AI responses can take a few seconds)
 *
 * restTemplate — plain instance for any internal service calls (no OpenAI token, tighter timeouts).
 */
@Configuration
public class OpenAIConfig {

    @Value("${openai.api.key}")
    private String openAiApiKey;

    @Value("${openai.connect.timeout.ms:10000}")
    private int connectTimeoutMs;

    @Value("${openai.read.timeout.ms:30000}")
    private int readTimeoutMs;

    /**
     * RestTemplate pre-configured with the OpenAI Bearer token and sensible timeouts.
     * Injected into ChatbotService via @Qualifier("openAiRestTemplate").
     */
    @Bean(name = "openAiRestTemplate")
    public RestTemplate openAiRestTemplate() {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(connectTimeoutMs);
        factory.setReadTimeout(readTimeoutMs);

        RestTemplate restTemplate = new RestTemplate(factory);

        // Attach the Authorization header to every request automatically
        ClientHttpRequestInterceptor authInterceptor = (request, body, execution) -> {
            request.getHeaders().set("Authorization", "Bearer " + openAiApiKey);
            request.getHeaders().set("Content-Type", "application/json");
            return execution.execute(request, body);
        };

        restTemplate.setInterceptors(List.of(authInterceptor));
        return restTemplate;
    }

    /**
     * Plain RestTemplate for any internal service calls (no OpenAI token).
     * Uses tighter timeouts appropriate for internal microservice calls.
     */
    @Bean(name = "restTemplate")
    public RestTemplate restTemplate() {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(5000);
        factory.setReadTimeout(10000);
        return new RestTemplate(factory);
    }
}