package com.gympro.chatbot.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Outgoing chat response sent back to the client.
 *
 * reply          – the chatbot's answer text
 * conversationId – echo the session ID back; frontend must store and re-send this
 * timestamp      – server time when the reply was generated
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChatResponse {

    private String reply;
    private String conversationId;
    private LocalDateTime timestamp;
}
