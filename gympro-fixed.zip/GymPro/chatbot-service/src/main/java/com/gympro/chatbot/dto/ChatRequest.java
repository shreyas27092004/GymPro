package com.gympro.chatbot.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Incoming chat request from the client.
 *
 * message        – the user's message text
 * role           – the user's role: MEMBER | TRAINER | ADMIN (used for context-aware replies)
 * conversationId – unique session ID to maintain conversation history.
 *                  Generate a UUID on the frontend and re-send it with each message.
 *                  Pass null or omit to start a new conversation (service assigns a new ID).
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChatRequest {

    private String message;

    /** MEMBER | TRAINER | ADMIN – defaults to MEMBER if null/empty */
    private String role;

    /** UUID-style session token; null = new conversation */
    private String conversationId;
}
