# GymPro – Docker Setup Guide

## Folder Structure Expected

```
gympro-docker/                  ← this folder
├── docker-compose.yml
├── .env.example
├── frontend/
│   ├── Dockerfile
│   └── nginx.conf
├── mysql-init/
│   └── 01-init-databases.sql
├── configs/
│   └── auth-service-docker.properties
└── Dockerfile.service          ← copy into each Spring Boot service folder

GymPro/                         ← your backend (from GymPro.zip)
│   ├── auth-service/
│   ├── gateway-service/
│   ├── eureka-server/
│   ├── member-service/
│   ├── trainer-service/
│   ├── plan-service/
│   ├── booking-service/
│   ├── payment-service/
│   ├── notification-service/
│   └── chatbot-service/

gympro-frontend/                ← your frontend (from gympro-frontend.zip)
│   ├── Dockerfile              ← copy from frontend/Dockerfile
│   ├── nginx.conf              ← copy from frontend/nginx.conf
│   ├── src/
│   └── package.json
```

---

## Step 1: Copy Dockerfiles into each service

Run this once to copy the Dockerfile into all Spring Boot services:

```bash
for svc in auth-service gateway-service eureka-server member-service trainer-service plan-service booking-service payment-service notification-service chatbot-service; do
  cp Dockerfile.service GymPro/$svc/Dockerfile
done

cp frontend/Dockerfile gympro-frontend/Dockerfile
cp frontend/nginx.conf gympro-frontend/nginx.conf
```

---

## Step 2: Update application.properties in each service

Replace `localhost` with Docker service names in each service's `application.properties`:

| localhost reference     | Docker service name  |
|------------------------|----------------------|
| localhost:3306          | mysql:3306           |
| localhost:8761          | eureka-server:8761   |
| localhost:5672          | rabbitmq:5672        |

Quick sed command:
```bash
cd GymPro
for svc in auth-service member-service trainer-service plan-service booking-service payment-service notification-service chatbot-service; do
  sed -i 's/localhost:3306/mysql:3306/g' $svc/src/main/resources/application.properties
  sed -i 's/localhost:8761/eureka-server:8761/g' $svc/src/main/resources/application.properties
  sed -i 's/spring.rabbitmq.host=localhost/spring.rabbitmq.host=rabbitmq/g' $svc/src/main/resources/application.properties
done
sed -i 's/localhost:8761/eureka-server:8761/g' gateway-service/src/main/resources/application.properties
```

---

## Step 3: Set up environment file

```bash
cp .env.example .env
# Edit .env with your real OpenAI key if using chatbot
```

---

## Step 4: Run everything

```bash
# Build and start all 14 containers
docker-compose up --build

# Run in background
docker-compose up --build -d

# Watch logs
docker-compose logs -f

# Watch specific service
docker-compose logs -f auth-service
```

---

## Service URLs after startup

| Service         | URL                              |
|----------------|----------------------------------|
| Frontend        | http://localhost                 |
| Gateway         | http://localhost:8080            |
| Eureka Dashboard| http://localhost:8761            |
| RabbitMQ UI     | http://localhost:15672 (guest/guest) |
| Auth API        | http://localhost:8081            |
| Member API      | http://localhost:8082            |
| Trainer API     | http://localhost:8083            |
| Plan API        | http://localhost:8084            |
| Booking API     | http://localhost:8085            |
| Notification API| http://localhost:8086            |
| Payment API     | http://localhost:8087            |
| Chatbot API     | http://localhost:8088            |

---

## Startup Order (handled automatically by depends_on)

```
MySQL + RabbitMQ  →  Eureka  →  Gateway  →  All business services  →  Frontend
```

---

## Useful Commands

```bash
# Stop everything (keep volumes)
docker-compose down

# Stop and wipe all data (fresh DB)
docker-compose down -v

# Rebuild only one service after code change
docker-compose up --build auth-service

# Check running containers
docker ps

# Open shell in a running container
docker exec -it gympro-auth sh

# View MySQL databases
docker exec -it gympro-mysql mysql -uroot -proot -e "SHOW DATABASES;"
```

---

## Known Issues (from blueprint)

- Notification system not fully working — email config may need valid Gmail app password
- Chatbot gateway route is blocked — set OPENAI_API_KEY in .env
- Redux Toolkit — already in package.json, will install correctly via npm install in Docker build
- Admin health metrics are static — no action needed for initial version
