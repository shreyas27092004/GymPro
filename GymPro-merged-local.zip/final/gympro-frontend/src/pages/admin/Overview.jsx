// src/pages/admin/Overview.jsx

import { useState, useEffect, useCallback, useRef } from 'react';
import { memberApi, trainerApi, planApi, paymentApi } from '../../api/api';
import { SkeletonAdminOverview } from '../../components/Skeleton';

const POLL_INTERVAL_MS = 30_000;
const TIMEOUT_MS       = 8_000;

const SERVICES = [
  { id: 'gateway',      name: 'GATEWAY-SERVICE',      port: 8080, url: '/api/gateway/actuator/health'  },
  { id: 'auth',         name: 'AUTH-SERVICE',          port: 8081, url: '/api/auth/actuator/health'     },
  { id: 'member',       name: 'MEMBER-SERVICE',        port: 8082, url: '/api/members/actuator/health'  },
  { id: 'trainer',      name: 'TRAINER-SERVICE',       port: 8083, url: '/api/trainers/actuator/health' },
  { id: 'plan',         name: 'PLAN-SERVICE',          port: 8084, url: '/api/plans/actuator/health'    },
  { id: 'booking',      name: 'BOOKING-SERVICE',       port: 8085, url: '/api/bookings/actuator/health' },
  { id: 'notification', name: 'NOTIFICATION-SERVICE',  port: 8086, url: '/api/notify/actuator/health'   },
  { id: 'payment',      name: 'PAYMENT-SERVICE',       port: 8087, url: '/api/payments/actuator/health' },
  { id: 'chatbot',      name: 'CHATBOT-SERVICE',       port: 8088, url: '/api/chatbot/actuator/health'  },
];

const STATUS = Object.freeze({ UP: 'UP', DOWN: 'DOWN', CHECKING: 'CHECKING', DEGRADED: 'DEGRADED' });

// ── Health check ──────────────────────────────────────────────────────────────
// Routing chain (Docker):
//   Browser → nginx (strips /api/) → gateway :8080 → lb://service via Eureka
//
// We call /actuator/health directly (NOT /liveness) because:
//   • The gateway's own actuator doesn't have a liveness sub-path exposed
//   • Individual services return 500 on /liveness if Spring context not fully ready
//   • /actuator/health returns 200 (UP) or 503 (DOWN sub-component) — both mean alive
//
// Status mapping:
//   HTTP 200 + body.status=UP           → UP
//   HTTP 503 + body.status=DOWN         → DEGRADED (alive but a DB/MQ component is down)
//   HTTP 502 (gateway can't route yet)  → DOWN (Eureka not registered yet)
//   Timeout / network error             → DOWN
async function checkService(svc) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  const t0 = performance.now();

  try {
    const res = await fetch(`/api/${svc.healthPath}`, { signal: controller.signal });
    const latencyMs = Math.round(performance.now() - t0);

    // 200 = healthy, 503 = alive but a sub-component is degraded.
    // Anything else (502 = no Eureka route, 404, 401, etc.) = DOWN.
    if (res.status !== 200 && res.status !== 503) {
      return { status: STATUS.DOWN, latencyMs };
    }

    let body = {};
    try { body = await res.json(); } catch {
      // Got a response but not JSON — still alive
      return { status: STATUS.DEGRADED, latencyMs };
    }

    const s = body?.status;
    if (s === 'UP' || s === 'OUT_OF_SERVICE' || s === 'UNKNOWN') {
      return { status: STATUS.UP, latencyMs };
    }
    if (s === 'DOWN') {
      // JVM is alive and answered, but a sub-component (DB, RabbitMQ) is unhealthy
      return { status: STATUS.DEGRADED, latencyMs };
    }

    return { status: STATUS.DEGRADED, latencyMs };

  } catch (err) {
    const latencyMs = Math.round(performance.now() - t0);
    return { status: STATUS.DOWN, latencyMs: err.name === 'AbortError' ? null : latencyMs };
  } finally {
    clearTimeout(timer);
  }
}

function makeInitialServices() {
  return SERVICES.map(s => ({ ...s, status: STATUS.CHECKING, latencyMs: null }));
}

export default function AdminOverview({ onNav }) {
  const [stats,        setStats]        = useState(null);
  const [statsLoading, setStatsLoading] = useState(true);
  const [statsError,   setStatsError]   = useState(false);
  const [services,     setServices]     = useState(makeInitialServices);
  const [lastChecked,  setLastChecked]  = useState(null);
  const [checking,     setChecking]     = useState(false);
  const checkingRef = useRef(false);
  const intervalRef = useRef(null);

  // ── Load stats ────────────────────────────────────────────────────────────
  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      setStatsLoading(true);
      setStatsError(false);
      try {
        const [membersRes, trainersRes, plansRes, paymentsRes] = await Promise.allSettled([
          memberApi.getAll(),
          trainerApi.getAll(),
          planApi.getAll(),
          paymentApi.getAll(),
        ]);
        if (cancelled) return;
        const allFailed = [membersRes, trainersRes, plansRes, paymentsRes].every(r => r.status === 'rejected');
        if (allFailed) {
          setStatsError(true);
        } else {
          const members  = membersRes.status  === 'fulfilled' ? membersRes.value.data  : [];
          const trainers = trainersRes.status === 'fulfilled' ? trainersRes.value.data : [];
          const plans    = plansRes.status    === 'fulfilled' ? plansRes.value.data    : [];
          const payments = paymentsRes.status === 'fulfilled' ? paymentsRes.value.data : [];
          setStats({
            members:       members.length,
            activeMembers: members.filter(m => m.status === 'ACTIVE').length,
            trainers:      trainers.length,
            plans:         plans.length,
            payments:      payments.length,
          });
        }
      } catch {
        if (!cancelled) setStatsError(true);
      } finally {
        if (!cancelled) setStatsLoading(false);
      }
    };
    load();
    return () => { cancelled = true; };
  }, []);

  // ── Health checks ─────────────────────────────────────────────────────────
  const runHealthChecks = useCallback(async () => {
    // Prevent overlapping check runs using a ref (avoids stale closure issues)
    if (checkingRef.current) return;
    checkingRef.current = true;
    setChecking(true);
    setServices(makeInitialServices);

    await Promise.all(
      SERVICES.map(async (svc, idx) => {
        const { status, latencyMs } = await checkService(svc);
        setServices(prev => {
          const next = [...prev];
          next[idx] = { ...svc, status, latencyMs };
          return next;
        });
      })
    );

    setLastChecked(new Date());
    checkingRef.current = false;
    setChecking(false);
  }, []); // stable — no deps needed because we use checkingRef

  useEffect(() => {
    runHealthChecks();
    intervalRef.current = setInterval(runHealthChecks, POLL_INTERVAL_MS);
    return () => clearInterval(intervalRef.current);
  }, [runHealthChecks]);

  // ── Derived ───────────────────────────────────────────────────────────────
  const upCount       = services.filter(s => s.status === STATUS.UP).length;
  const degradedCount = services.filter(s => s.status === STATUS.DEGRADED).length;
  const downCount     = services.filter(s => s.status === STATUS.DOWN).length;
  const allUp         = downCount === 0 && degradedCount === 0 && services.every(s => s.status !== STATUS.CHECKING);

  const QUICK_ACTIONS = [
    { icon: '👥', label: 'Members',  desc: 'View & manage all gym members',   color: 'var(--accent)',  key: 'members'  },
    { icon: '💪', label: 'Trainers', desc: 'Assign and manage trainers',       color: 'var(--green)',   key: 'trainers' },
    { icon: '📋', label: 'Plans',    desc: 'Create & update membership plans', color: 'var(--amber)',   key: 'plans'    },
    { icon: '📅', label: 'Bookings', desc: 'View all session bookings',        color: 'var(--purple)',  key: 'bookings' },
    { icon: '💳', label: 'Payments', desc: 'Track payment transactions',       color: 'var(--red)',     key: 'payments' },
  ];

  const STAT_CARDS = [
    { label: 'Total Members',   value: stats?.members,       color: 'var(--accent)', icon: '👥' },
    { label: 'Active Members',  value: stats?.activeMembers, color: 'var(--green)',  icon: '✅' },
    { label: 'Trainers',        value: stats?.trainers,      color: 'var(--amber)',  icon: '💪' },
    { label: 'Plans Available', value: stats?.plans,         color: 'var(--purple)', icon: '📋' },
    { label: 'Total Payments',  value: stats?.payments,      color: 'var(--red)',    icon: '💳' },
  ];

  return (
    <div className="fade-in">
      <div className="content-header">
        <div className="page-title">OVERVIEW</div>
        <div className="page-subtitle">Welcome back, Admin — here's your gym at a glance</div>
      </div>

      <div className="content-body">

        {statsError && !statsLoading && (
          <div style={S.errorBanner}>
            <span>⚠️</span>
            <div>
              <div style={{ fontWeight: 700, fontSize: 13, color: '#ff4d6d' }}>Backend Unavailable</div>
              <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 2 }}>
                Could not reach the API gateway. Start your microservices and refresh.
              </div>
            </div>
            <button style={S.retryBtn} onClick={() => window.location.reload()}>Retry</button>
          </div>
        )}

        {statsLoading ? (
          <SkeletonAdminOverview />
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 14, marginBottom: 28 }}>
            {STAT_CARDS.map(s => (
              <div key={s.label} className="stat-card">
                <div className="stat-accent-bar" style={{ background: s.color }} />
                <div className="stat-icon">{s.icon}</div>
                <div className="stat-value" style={{ color: s.color }}>
                  {s.value != null ? s.value : statsError ? '—' : '…'}
                </div>
                <div className="stat-label">{s.label}</div>
              </div>
            ))}
          </div>
        )}

        <div style={{ marginBottom: 24 }}>
          <div style={S.sectionLabel}>Quick Access</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: 12 }}>
            {QUICK_ACTIONS.map(a => <QuickActionButton key={a.key} action={a} onNav={onNav} />)}
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>

          <div className="card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)' }}>⚙️ System Services</span>
                <span style={{
                  padding: '2px 8px', borderRadius: 20, fontSize: 11, fontWeight: 600,
                  background: allUp ? 'rgba(0,229,160,0.15)' : downCount > 0 ? 'rgba(255,77,109,0.15)' : 'rgba(255,215,0,0.12)',
                  color:      allUp ? '#00e5a0' : downCount > 0 ? '#ff4d6d' : '#ffd700',
                  border: `1px solid ${allUp ? 'rgba(0,229,160,0.3)' : downCount > 0 ? 'rgba(255,77,109,0.3)' : 'rgba(255,215,0,0.3)'}`,
                }}>
                  {upCount}/{SERVICES.length} UP{degradedCount > 0 ? ` · ${degradedCount} DEGRADED` : ''}
                </span>
              </div>
              <button
                onClick={runHealthChecks}
                disabled={checking}
                style={{
                  background: 'var(--bg3)', border: '1px solid var(--border)',
                  borderRadius: 8, padding: '4px 10px', cursor: checking ? 'default' : 'pointer',
                  color: 'var(--text3)', fontSize: 12, display: 'flex', alignItems: 'center', gap: 5,
                  fontFamily: 'var(--font-body)', opacity: checking ? 0.5 : 1, transition: 'opacity 0.2s',
                }}
              >
                <span style={{ display: 'inline-block', animation: checking ? 'gp-spin 1s linear infinite' : 'none' }}>↻</span>
                {checking ? 'Checking…' : 'Refresh'}
              </button>
            </div>

            {services.map((svc, i) => (
              <ServiceRow key={svc.id} svc={svc} isLast={i === services.length - 1} />
            ))}

            <div style={{ marginTop: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 11, color: 'var(--text3)' }}>
                {lastChecked ? `Last checked: ${lastChecked.toLocaleTimeString()}` : 'Checking…'}
              </span>
              <span style={S.pollBadge}>⏱ Auto-refresh 30s</span>
            </div>
          </div>

          <div className="card">
            <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)', marginBottom: 16 }}>🏗️ Architecture</div>
            {ARCH_ROWS.map(item => (
              <div key={item.label} style={S.archRow}>
                <span style={{ fontSize: 13, color: 'var(--text3)' }}>{item.label}</span>
                <span style={{ fontSize: 13, color: 'var(--accent)', fontWeight: 600 }}>{item.value}</span>
              </div>
            ))}
          </div>
        </div>

      </div>
      <style>{`@keyframes gp-spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}@keyframes gp-pulse{0%,100%{opacity:1}50%{opacity:0.25}}`}</style>
    </div>
  );
}

function ServiceRow({ svc, isLast }) {
  const isUp       = svc.status === STATUS.UP;
  const isDegraded = svc.status === STATUS.DEGRADED;
  const isChecking = svc.status === STATUS.CHECKING;

  const dotColor = isUp ? '#00e5a0' : isDegraded ? '#ffd700' : isChecking ? '#a0a0a0' : '#ff4d6d';

  const badgeStyle = isUp       ? { background: 'rgba(0,229,160,0.15)',   color: '#00e5a0', border: '1px solid rgba(0,229,160,0.3)'  }
                   : isDegraded ? { background: 'rgba(255,215,0,0.12)',   color: '#ffd700', border: '1px solid rgba(255,215,0,0.3)'  }
                   : isChecking ? { background: 'rgba(160,160,160,0.12)', color: '#a0a0a0', border: '1px solid rgba(160,160,160,0.3)' }
                   :              { background: 'rgba(255,77,109,0.15)',   color: '#ff4d6d', border: '1px solid rgba(255,77,109,0.3)'  };

  const badgeLabel = isChecking ? '…' : isUp ? 'UP' : isDegraded ? 'DEGRADED' : 'DOWN';

  return (
    <div style={{
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      padding: '9px 0',
      borderBottom: isLast ? 'none' : '1px solid var(--border)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
        <span style={{
          width: 8, height: 8, borderRadius: '50%', flexShrink: 0,
          background: dotColor,
          boxShadow: `0 0 6px ${dotColor}88`,
          animation: isChecking ? 'gp-pulse 1s ease-in-out infinite'
                   : isDegraded ? 'gp-pulse 2s ease-in-out infinite'
                   : 'none',
        }} />
        <span style={{ fontSize: 13, color: 'var(--text2)' }}>{svc.name}</span>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        {svc.latencyMs != null && !isChecking && (
          <span style={{ fontSize: 10, color: 'var(--text3)' }}>{svc.latencyMs}ms</span>
        )}
        <span style={{ fontSize: 11, color: 'var(--text3)' }}>:{svc.port}</span>
        <span style={{
          padding: '2px 8px', borderRadius: 20,
          fontSize: 10, fontWeight: 700, letterSpacing: '0.5px',
          minWidth: 42, textAlign: 'center',
          ...badgeStyle,
        }}>
          {badgeLabel}
        </span>
      </div>
    </div>
  );
}

function QuickActionButton({ action: a, onNav }) {
  const [hovered, setHovered] = useState(false);
  return (
    <button
      onClick={() => onNav(a.key)}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: 'var(--bg3)',
        border: `1px solid ${hovered ? a.color : 'var(--border)'}`,
        borderRadius: 14, padding: '18px 14px', cursor: 'pointer',
        textAlign: 'left', fontFamily: 'var(--font-body)',
        transform: hovered ? 'translateY(-2px)' : 'none',
        transition: 'all 0.2s',
      }}
    >
      <div style={{ fontSize: 22, marginBottom: 8 }}>{a.icon}</div>
      <div style={{ fontWeight: 700, color: a.color, fontSize: 12, marginBottom: 3 }}>{a.label}</div>
      <div style={{ fontSize: 11, color: 'var(--text3)', lineHeight: 1.4 }}>{a.desc}</div>
    </button>
  );
}

const ARCH_ROWS = [
  { label: 'Pattern',           value: 'Microservices'          },
  { label: 'Service Discovery', value: 'Eureka Server'          },
  { label: 'Gateway',           value: 'Spring Cloud Gateway'   },
  { label: 'Auth',              value: 'JWT Bearer Tokens'      },
  { label: 'Database',          value: 'Per-service MySQL DB'   },
  { label: 'Messaging',         value: 'RabbitMQ (AMQP)'       },
  { label: 'Payments',          value: 'Razorpay + UPI / Cash' },
  { label: 'Notifications',     value: 'Email SMTP + In-App DB'},
];

const S = {
  sectionLabel: { fontSize: 11, fontWeight: 700, color: 'var(--text3)', letterSpacing: '1.5px', textTransform: 'uppercase', marginBottom: 12 },
  errorBanner:  { display: 'flex', alignItems: 'flex-start', gap: 12, background: 'rgba(255,77,109,0.08)', border: '1px solid rgba(255,77,109,0.25)', borderRadius: 12, padding: '14px 16px', marginBottom: 20 },
  retryBtn:     { marginLeft: 'auto', background: 'rgba(255,77,109,0.15)', border: '1px solid rgba(255,77,109,0.3)', borderRadius: 8, padding: '5px 12px', color: '#ff4d6d', fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: 'var(--font-body)' },
  pollBadge:    { fontSize: 10, color: 'var(--text3)', background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: 20, padding: '2px 8px' },
  archRow:      { display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)' },
};